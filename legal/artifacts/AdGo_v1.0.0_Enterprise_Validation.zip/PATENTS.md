# Patent Notice

AdGo Solutions Limited. Patent Notice

This software may be covered by one or more patents owned by AdGo Solutions Limited.
or licensed to AdGo Solutions Limited.. The use of this software may require a license
under such patents.

For patent licensing inquiries, please contact: patents@adgosolutions.com

Build: 20251015_073830
Generated: 2025-10-15 04:46:16 UTC
