// Mock API Service for AdGo Platform
import { CampaignData } from '../contexts/CampaignContext';
import { SubscriptionPlan } from '../contexts/SubscriptionContext';

// Mock delay to simulate network requests
const mockDelay = (ms: number = 1000) => new Promise(resolve => setTimeout(resolve, ms));

// Mock data
const MOCK_CAMPAIGNS: CampaignData[] = [
  {
    id: 'camp_001',
    name: 'Summer Sale Campaign',
    status: 'active',
    creative: {
      file: null,
      fileName: 'summer-sale.jpg',
      fileSize: 2400000,
      fileType: 'image/jpeg',
      landingUrl: 'https://example.com/summer-sale',
      ctaText: 'Shop Now'
    },
    targeting: {
      cities: ['nairobi', 'accra'],
      municipalities: ['Westlands', 'East Legon'],
      radiusTargeting: false,
      ageRange: [25, 45],
      gender: 'all',
      languages: ['en'],
      estimatedReach: 300000
    },
    schedule: {
      startDate: '2024-02-01',
      endDate: '2024-02-15',
      daypart: 'commute',
      timezone: 'UTC'
    },
    budget: {
      type: 'total',
      amount: 500,
      objective: 'awareness',
      frequencyEnabled: true,
      frequencyCap: 3,
      estimatedImpressions: 200000,
      estimatedClicks: 5600,
      estimatedCPM: 2.5,
      estimatedCPC: 0.089
    },
    createdAt: '2024-01-25T10:00:00Z',
    updatedAt: '2024-01-25T10:00:00Z'
  },
  {
    id: 'camp_002',
    name: 'Holiday Special',
    status: 'paused',
    creative: {
      file: null,
      fileName: 'holiday-promo.mp4',
      fileSize: 8900000,
      fileType: 'video/mp4',
      landingUrl: 'https://example.com/holiday',
      ctaText: 'Get Offer'
    },
    targeting: {
      cities: ['cape-town', 'kigali'],
      municipalities: ['City Bowl', 'Gasabo'],
      radiusTargeting: true,
      ageRange: [18, 35],
      gender: 'all',
      languages: ['en'],
      estimatedReach: 280000
    },
    schedule: {
      startDate: '2024-01-15',
      endDate: '2024-01-31',
      daypart: 'evenings',
      timezone: 'UTC'
    },
    budget: {
      type: 'daily',
      amount: 50,
      objective: 'traffic',
      frequencyEnabled: true,
      frequencyCap: 2,
      estimatedImpressions: 25000,
      estimatedClicks: 750,
      estimatedCPM: 3.5,
      estimatedCPC: 1.2
    },
    createdAt: '2024-01-10T14:30:00Z',
    updatedAt: '2024-01-20T09:15:00Z'
  }
];

const MOCK_ANALYTICS = {
  overview: {
    totalImpressions: 245830,
    totalClicks: 6874,
    totalSpend: 1234.56,
    averageCTR: 2.8,
    averageCPM: 2.75,
    averageCPC: 0.18
  },
  performance: [
    { date: '2024-01-25', impressions: 12400, clicks: 347, spend: 62.00, ctr: 2.8 },
    { date: '2024-01-26', impressions: 15600, clicks: 424, spend: 78.40, ctr: 2.7 },
    { date: '2024-01-27', impressions: 18200, clicks: 546, spend: 91.00, ctr: 3.0 },
    { date: '2024-01-28', impressions: 16800, clicks: 487, spend: 84.20, ctr: 2.9 },
    { date: '2024-01-29', impressions: 14300, clicks: 401, spend: 71.50, ctr: 2.8 },
    { date: '2024-01-30', impressions: 19200, clicks: 576, spend: 96.00, ctr: 3.0 },
    { date: '2024-01-31', impressions: 17400, clicks: 504, spend: 87.00, ctr: 2.9 }
  ],
  geographic: [
    { city: 'Nairobi', impressions: 85400, clicks: 2562, spend: 427.00, ctr: 3.0 },
    { city: 'Accra', impressions: 67200, clicks: 1881, spend: 336.00, ctr: 2.8 },
    { city: 'Cape Town', impressions: 54800, clicks: 1644, spend: 274.00, ctr: 3.0 },
    { city: 'Kigali', impressions: 38430, clicks: 999, spend: 197.56, ctr: 2.6 }
  ]
};

// Campaign API
export const campaignAPI = {
  // Get all campaigns for a user
  async getCampaigns(userId: string): Promise<CampaignData[]> {
    await mockDelay(800);
    return MOCK_CAMPAIGNS;
  },

  // Get a specific campaign
  async getCampaign(campaignId: string): Promise<CampaignData | null> {
    await mockDelay(600);
    return MOCK_CAMPAIGNS.find(c => c.id === campaignId) || null;
  },

  // Create a new campaign
  async createCampaign(campaignData: Omit<CampaignData, 'id' | 'createdAt' | 'updatedAt'>): Promise<CampaignData> {
    await mockDelay(1200);
    
    const newCampaign: CampaignData = {
      ...campaignData,
      id: `camp_${Date.now()}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    MOCK_CAMPAIGNS.push(newCampaign);
    return newCampaign;
  },

  // Update an existing campaign
  async updateCampaign(campaignId: string, updates: Partial<CampaignData>): Promise<CampaignData> {
    await mockDelay(1000);
    
    const campaignIndex = MOCK_CAMPAIGNS.findIndex(c => c.id === campaignId);
    if (campaignIndex === -1) {
      throw new Error('Campaign not found');
    }

    MOCK_CAMPAIGNS[campaignIndex] = {
      ...MOCK_CAMPAIGNS[campaignIndex],
      ...updates,
      updatedAt: new Date().toISOString()
    };

    return MOCK_CAMPAIGNS[campaignIndex];
  },

  // Delete a campaign
  async deleteCampaign(campaignId: string): Promise<void> {
    await mockDelay(800);
    
    const campaignIndex = MOCK_CAMPAIGNS.findIndex(c => c.id === campaignId);
    if (campaignIndex === -1) {
      throw new Error('Campaign not found');
    }

    MOCK_CAMPAIGNS.splice(campaignIndex, 1);
  },

  // Launch a campaign (change status to pending_review)
  async launchCampaign(campaignId: string): Promise<CampaignData> {
    await mockDelay(1500);
    
    const campaign = await campaignAPI.updateCampaign(campaignId, { 
      status: 'pending_review' 
    });
    
    // Simulate review process (auto-approve after delay)
    setTimeout(async () => {
      await campaignAPI.updateCampaign(campaignId, { status: 'active' });
    }, 3000);

    return campaign;
  },

  // Pause/Resume campaign
  async toggleCampaignStatus(campaignId: string): Promise<CampaignData> {
    await mockDelay(600);
    
    const campaign = MOCK_CAMPAIGNS.find(c => c.id === campaignId);
    if (!campaign) {
      throw new Error('Campaign not found');
    }

    const newStatus = campaign.status === 'active' ? 'paused' : 'active';
    return await campaignAPI.updateCampaign(campaignId, { status: newStatus });
  }
};

// Analytics API
export const analyticsAPI = {
  // Get campaign analytics
  async getCampaignAnalytics(campaignId: string, timeRange: string = '30d') {
    await mockDelay(1200);
    
    // Filter mock data based on time range
    const endDate = new Date();
    const startDate = new Date();
    
    switch (timeRange) {
      case '7d':
        startDate.setDate(endDate.getDate() - 7);
        break;
      case '30d':
        startDate.setDate(endDate.getDate() - 30);
        break;
      case '90d':
        startDate.setDate(endDate.getDate() - 90);
        break;
    }

    return {
      ...MOCK_ANALYTICS,
      timeRange,
      campaign: MOCK_CAMPAIGNS.find(c => c.id === campaignId)
    };
  },

  // Get overall account analytics
  async getAccountAnalytics(timeRange: string = '30d') {
    await mockDelay(1000);
    return {
      ...MOCK_ANALYTICS,
      timeRange
    };
  },

  // Export analytics data
  async exportAnalytics(campaignId: string, format: 'csv' | 'pdf', email: string) {
    await mockDelay(2000);
    
    // Mock export process
    return {
      success: true,
      downloadUrl: `https://api.adgo.com/exports/${campaignId}-analytics.${format}`,
      message: `Analytics exported successfully. Download link sent to ${email}`
    };
  }
};

// File Upload API
export const uploadAPI = {
  // Upload creative file
  async uploadCreative(file: File): Promise<{ url: string; publicId: string }> {
    await mockDelay(2000);
    
    // Simulate file upload validation
    const maxSize = 10 * 1024 * 1024; // 10MB
    if (file.size > maxSize) {
      throw new Error('File size exceeds 10MB limit');
    }

    const validTypes = ['image/jpeg', 'image/png', 'image/webp', 'video/mp4', 'video/webm'];
    if (!validTypes.includes(file.type)) {
      throw new Error('Invalid file type');
    }

    // Mock successful upload
    const publicId = `creative_${Date.now()}`;
    const url = URL.createObjectURL(file); // Create blob URL for preview

    return { url, publicId };
  },

  // Delete uploaded file
  async deleteCreative(publicId: string): Promise<void> {
    await mockDelay(500);
    // Mock deletion - in real app would delete from cloud storage
  }
};

// Subscription API
export const subscriptionAPI = {
  // Get current subscription
  async getSubscription(userId: string) {
    await mockDelay(800);
    return {
      plan: 'free' as SubscriptionPlan,
      status: 'active',
      billingCycle: 'monthly',
      price: 0,
      renewalDate: null,
      features: {
        maxCampaigns: 3,
        advancedTargeting: false,
        premiumSupport: false
      }
    };
  },

  // Upgrade subscription
  async upgradeSubscription(userId: string, plan: SubscriptionPlan, billingCycle: 'monthly' | 'yearly') {
    await mockDelay(1500);
    
    const pricing = {
      premium: { monthly: 49, yearly: 490 },
      enterprise: { monthly: 199, yearly: 1990 }
    };

    return {
      success: true,
      plan,
      billingCycle,
      price: pricing[plan as keyof typeof pricing][billingCycle],
      message: 'Subscription upgraded successfully'
    };
  },

  // Cancel subscription
  async cancelSubscription(userId: string) {
    await mockDelay(1000);
    return {
      success: true,
      message: 'Subscription cancelled. You can continue using premium features until the end of your billing period.'
    };
  }
};

// Reports API
export const reportsAPI = {
  // Schedule automated report
  async scheduleReport(reportConfig: {
    campaignId: string;
    frequency: 'daily' | 'weekly' | 'monthly';
    format: 'pdf' | 'csv' | 'email';
    recipients: string[];
    metrics: string[];
    customMessage?: string;
  }) {
    await mockDelay(1000);
    
    return {
      success: true,
      reportId: `report_${Date.now()}`,
      message: 'Report scheduled successfully',
      nextDelivery: '2024-02-01T09:00:00Z'
    };
  },

  // Get scheduled reports
  async getScheduledReports(userId: string) {
    await mockDelay(600);
    
    return [
      {
        id: 'report_001',
        campaignId: 'camp_001',
        campaignName: 'Summer Sale Campaign',
        frequency: 'weekly',
        format: 'pdf',
        recipients: ['user@example.com'],
        nextDelivery: '2024-02-05T09:00:00Z',
        isActive: true
      }
    ];
  },

  // Update report schedule
  async updateReportSchedule(reportId: string, updates: any) {
    await mockDelay(800);
    return { success: true, message: 'Report schedule updated' };
  },

  // Delete report schedule
  async deleteReportSchedule(reportId: string) {
    await mockDelay(500);
    return { success: true, message: 'Report schedule deleted' };
  }
};

// Auth API
export const authAPI = {
  // Mock login
  async login(email: string, password: string) {
    await mockDelay(1200);
    
    // Mock authentication
    if (email === 'demo@adgo.com' && password === 'demo') {
      return {
        success: true,
        user: {
          id: 'user_001',
          email: 'demo@adgo.com',
          name: 'Demo User',
          role: 'advertiser' as const,
          company: 'Demo Company'
        },
        token: 'mock_jwt_token_12345'
      };
    }
    
    throw new Error('Invalid credentials');
  },

  // Mock registration
  async register(userData: {
    email: string;
    password: string;
    name: string;
    company?: string;
    role: 'advertiser' | 'admin';
  }) {
    await mockDelay(1500);
    
    return {
      success: true,
      user: {
        id: `user_${Date.now()}`,
        ...userData
      },
      token: 'mock_jwt_token_67890'
    };
  },

  // Mock logout
  async logout() {
    await mockDelay(300);
    return { success: true };
  }
};