import { useState } from 'react';
import { LandingPage } from './components/LandingPage';
import { AuthPage } from './components/AuthPage';
import { Dashboard } from './components/Dashboard';
import { AdUpload } from './components/AdUpload';
import { CampaignManagement } from './components/CampaignManagement';
import { Analytics } from './components/Analytics';
import { Settings } from './components/Settings';
import { AdminPanel } from './components/AdminPanel';
import { AdCreativeUpload } from './components/AdCreativeUpload';
import { Targeting } from './components/Targeting';
import { ScheduleBudget } from './components/ScheduleBudget';
import { ReviewPolicy } from './components/ReviewPolicy';
import { CampaignDashboard } from './components/CampaignDashboard';
import { ReportScheduling } from './components/ReportScheduling';
import { CampaignProvider } from './contexts/CampaignContext';
import { SubscriptionProvider } from './contexts/SubscriptionContext';

export type Screen = 'landing' | 'auth' | 'dashboard' | 'ad-upload' | 'campaigns' | 'analytics' | 'settings' | 'admin' | 
  'ad-creative-upload' | 'targeting' | 'schedule-budget' | 'review-policy' | 'campaign-dashboard' | 'report-scheduling';
export type UserRole = 'advertiser' | 'admin';

export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  company?: string;
  subscription?: 'free' | 'premium' | 'enterprise';
}

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('landing');
  const [user, setUser] = useState<User | null>(null);

  const navigateTo = (screen: Screen) => {
    setCurrentScreen(screen);
  };

  const handleLogin = (userData: User) => {
    setUser(userData);
    setCurrentScreen('dashboard');
  };

  const handleLogout = () => {
    setUser(null);
    setCurrentScreen('landing');
  };

  // Determine subscription plan for context
  const subscriptionPlan = user?.subscription || 'free';

  // Show appropriate screen with context providers
  const renderScreen = () => {
    switch (currentScreen) {
      case 'landing':
        return <LandingPage onNavigate={navigateTo} />;
        
      case 'auth':
        return <AuthPage onNavigate={navigateTo} onLogin={handleLogin} />;
        
      case 'dashboard':
        return <Dashboard user={user} onNavigate={navigateTo} onLogout={handleLogout} />;
        
      case 'ad-upload':
        return <AdUpload user={user} onNavigate={navigateTo} onLogout={handleLogout} />;
        
      case 'campaigns':
        return <CampaignManagement user={user} onNavigate={navigateTo} onLogout={handleLogout} />;
        
      case 'analytics':
        return <Analytics user={user} onNavigate={navigateTo} onLogout={handleLogout} />;
        
      case 'settings':
        return <Settings user={user} onNavigate={navigateTo} onLogout={handleLogout} />;
        
      case 'admin':
        return <AdminPanel user={user} onNavigate={navigateTo} onLogout={handleLogout} />;

      case 'ad-creative-upload':
        return <AdCreativeUpload user={user} onNavigate={navigateTo} onLogout={handleLogout} />;
        
      case 'targeting':
        return <Targeting user={user} onNavigate={navigateTo} onLogout={handleLogout} />;
        
      case 'schedule-budget':
        return <ScheduleBudget user={user} onNavigate={navigateTo} onLogout={handleLogout} />;
        
      case 'review-policy':
        return <ReviewPolicy user={user} onNavigate={navigateTo} onLogout={handleLogout} />;
        
      case 'campaign-dashboard':
        return <CampaignDashboard user={user} onNavigate={navigateTo} onLogout={handleLogout} />;
        
      case 'report-scheduling':
        return <ReportScheduling user={user} onNavigate={navigateTo} onLogout={handleLogout} />;
        
      default:
        return <LandingPage onNavigate={navigateTo} />;
    }
  };

  return (
    <SubscriptionProvider initialPlan={subscriptionPlan}>
      <CampaignProvider>
        {renderScreen()}
      </CampaignProvider>
    </SubscriptionProvider>
  );
}