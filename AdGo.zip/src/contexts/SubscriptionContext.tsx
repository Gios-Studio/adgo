import { createContext, useContext, useState, ReactNode } from 'react';

export type SubscriptionPlan = 'free' | 'premium' | 'enterprise';

export interface SubscriptionFeatures {
  maxCampaigns: number;
  maxCitiesPerCampaign: number;
  advancedTargeting: boolean;
  municipalityTargeting: boolean;
  radiusTargeting: boolean;
  customDayparting: boolean;
  multiLanguage: boolean;
  advancedAnalytics: boolean;
  multipleReportRecipients: boolean;
  customReportScheduling: boolean;
  prioritySupport: boolean;
  advancedIntegrations: boolean;
}

export interface SubscriptionData {
  plan: SubscriptionPlan;
  features: SubscriptionFeatures;
  billingCycle: 'monthly' | 'yearly';
  price: number;
  currency: string;
  renewalDate?: string;
  isActive: boolean;
  usageStats: {
    campaignsUsed: number;
    citiesUsed: number;
    reportRecipientsUsed: number;
  };
}

const SUBSCRIPTION_FEATURES: Record<SubscriptionPlan, SubscriptionFeatures> = {
  free: {
    maxCampaigns: 3,
    maxCitiesPerCampaign: 1,
    advancedTargeting: false,
    municipalityTargeting: false,
    radiusTargeting: false,
    customDayparting: false,
    multiLanguage: false,
    advancedAnalytics: false,
    multipleReportRecipients: false,
    customReportScheduling: false,
    prioritySupport: false,
    advancedIntegrations: false,
  },
  premium: {
    maxCampaigns: 25,
    maxCitiesPerCampaign: 5,
    advancedTargeting: true,
    municipalityTargeting: true,
    radiusTargeting: true,
    customDayparting: true,
    multiLanguage: true,
    advancedAnalytics: true,
    multipleReportRecipients: true,
    customReportScheduling: true,
    prioritySupport: true,
    advancedIntegrations: false,
  },
  enterprise: {
    maxCampaigns: -1, // Unlimited
    maxCitiesPerCampaign: -1, // Unlimited
    advancedTargeting: true,
    municipalityTargeting: true,
    radiusTargeting: true,
    customDayparting: true,
    multiLanguage: true,
    advancedAnalytics: true,
    multipleReportRecipients: true,
    customReportScheduling: true,
    prioritySupport: true,
    advancedIntegrations: true,
  },
};

const PRICING = {
  free: { monthly: 0, yearly: 0 },
  premium: { monthly: 49, yearly: 490 },
  enterprise: { monthly: 199, yearly: 1990 },
};

interface SubscriptionContextType {
  subscription: SubscriptionData;
  hasFeature: (feature: keyof SubscriptionFeatures) => boolean;
  canUseFeature: (feature: keyof SubscriptionFeatures, currentUsage?: number) => boolean;
  upgradeToPremium: () => void;
  upgradeToEnterprise: () => void;
  downgradeToFree: () => void;
  changeBillingCycle: (cycle: 'monthly' | 'yearly') => void;
  isAtLimit: (feature: 'campaigns' | 'cities' | 'reportRecipients') => boolean;
  getUsagePercentage: (feature: 'campaigns' | 'cities' | 'reportRecipients') => number;
  getRemainingUsage: (feature: 'campaigns' | 'cities' | 'reportRecipients') => number;
}

const SubscriptionContext = createContext<SubscriptionContextType | undefined>(undefined);

interface SubscriptionProviderProps {
  children: ReactNode;
  initialPlan?: SubscriptionPlan;
}

export function SubscriptionProvider({ children, initialPlan = 'free' }: SubscriptionProviderProps) {
  const [subscription, setSubscription] = useState<SubscriptionData>({
    plan: initialPlan,
    features: SUBSCRIPTION_FEATURES[initialPlan],
    billingCycle: 'monthly',
    price: PRICING[initialPlan].monthly,
    currency: 'USD',
    renewalDate: initialPlan !== 'free' ? '2024-03-01' : undefined,
    isActive: true,
    usageStats: {
      campaignsUsed: 1,
      citiesUsed: 3,
      reportRecipientsUsed: 1,
    },
  });

  const hasFeature = (feature: keyof SubscriptionFeatures): boolean => {
    return subscription.features[feature] === true;
  };

  const canUseFeature = (feature: keyof SubscriptionFeatures, currentUsage = 0): boolean => {
    const featureValue = subscription.features[feature];
    
    if (typeof featureValue === 'boolean') {
      return featureValue;
    }
    
    if (typeof featureValue === 'number') {
      if (featureValue === -1) return true; // Unlimited
      return currentUsage < featureValue;
    }
    
    return false;
  };

  const upgradeToPremium = () => {
    setSubscription(prev => ({
      ...prev,
      plan: 'premium',
      features: SUBSCRIPTION_FEATURES.premium,
      price: PRICING.premium[prev.billingCycle],
      renewalDate: '2024-03-01',
    }));
  };

  const upgradeToEnterprise = () => {
    setSubscription(prev => ({
      ...prev,
      plan: 'enterprise',
      features: SUBSCRIPTION_FEATURES.enterprise,
      price: PRICING.enterprise[prev.billingCycle],
      renewalDate: '2024-03-01',
    }));
  };

  const downgradeToFree = () => {
    setSubscription(prev => ({
      ...prev,
      plan: 'free',
      features: SUBSCRIPTION_FEATURES.free,
      price: 0,
      renewalDate: undefined,
    }));
  };

  const changeBillingCycle = (cycle: 'monthly' | 'yearly') => {
    setSubscription(prev => ({
      ...prev,
      billingCycle: cycle,
      price: PRICING[prev.plan][cycle],
    }));
  };

  const isAtLimit = (feature: 'campaigns' | 'cities' | 'reportRecipients'): boolean => {
    const featureMap = {
      campaigns: 'maxCampaigns',
      cities: 'maxCitiesPerCampaign',
      reportRecipients: 'multipleReportRecipients',
    };

    const usageMap = {
      campaigns: subscription.usageStats.campaignsUsed,
      cities: subscription.usageStats.citiesUsed,
      reportRecipients: subscription.usageStats.reportRecipientsUsed,
    };

    const featureKey = featureMap[feature] as keyof SubscriptionFeatures;
    const featureValue = subscription.features[featureKey];
    const currentUsage = usageMap[feature];

    if (typeof featureValue === 'number') {
      if (featureValue === -1) return false; // Unlimited
      return currentUsage >= featureValue;
    }

    if (feature === 'reportRecipients') {
      return !featureValue && currentUsage >= 1; // Free plan allows 1 recipient
    }

    return false;
  };

  const getUsagePercentage = (feature: 'campaigns' | 'cities' | 'reportRecipients'): number => {
    const featureMap = {
      campaigns: 'maxCampaigns',
      cities: 'maxCitiesPerCampaign',
      reportRecipients: 'multipleReportRecipients',
    };

    const usageMap = {
      campaigns: subscription.usageStats.campaignsUsed,
      cities: subscription.usageStats.citiesUsed,
      reportRecipients: subscription.usageStats.reportRecipientsUsed,
    };

    const featureKey = featureMap[feature] as keyof SubscriptionFeatures;
    const featureValue = subscription.features[featureKey];
    const currentUsage = usageMap[feature];

    if (typeof featureValue === 'number') {
      if (featureValue === -1) return 0; // Unlimited, show 0%
      return Math.min((currentUsage / featureValue) * 100, 100);
    }

    if (feature === 'reportRecipients') {
      const maxRecipients = featureValue ? 10 : 1; // Premium allows 10, free allows 1
      return Math.min((currentUsage / maxRecipients) * 100, 100);
    }

    return 0;
  };

  const getRemainingUsage = (feature: 'campaigns' | 'cities' | 'reportRecipients'): number => {
    const featureMap = {
      campaigns: 'maxCampaigns',
      cities: 'maxCitiesPerCampaign',
      reportRecipients: 'multipleReportRecipients',
    };

    const usageMap = {
      campaigns: subscription.usageStats.campaignsUsed,
      cities: subscription.usageStats.citiesUsed,
      reportRecipients: subscription.usageStats.reportRecipientsUsed,
    };

    const featureKey = featureMap[feature] as keyof SubscriptionFeatures;
    const featureValue = subscription.features[featureKey];
    const currentUsage = usageMap[feature];

    if (typeof featureValue === 'number') {
      if (featureValue === -1) return Infinity; // Unlimited
      return Math.max(featureValue - currentUsage, 0);
    }

    if (feature === 'reportRecipients') {
      const maxRecipients = featureValue ? 10 : 1;
      return Math.max(maxRecipients - currentUsage, 0);
    }

    return 0;
  };

  return (
    <SubscriptionContext.Provider value={{
      subscription,
      hasFeature,
      canUseFeature,
      upgradeToPremium,
      upgradeToEnterprise,
      downgradeToFree,
      changeBillingCycle,
      isAtLimit,
      getUsagePercentage,
      getRemainingUsage,
    }}>
      {children}
    </SubscriptionContext.Provider>
  );
}

export function useSubscription() {
  const context = useContext(SubscriptionContext);
  if (context === undefined) {
    throw new Error('useSubscription must be used within a SubscriptionProvider');
  }
  return context;
}