import { createContext, useContext, useReducer, useState, ReactNode } from 'react';

// Campaign Data Types
export interface CreativeData {
  file: File | null;
  fileName: string;
  fileSize: number;
  fileType: string;
  landingUrl: string;
  ctaText: string;
  previewUrl?: string;
}

export interface TargetingData {
  cities: string[];
  municipalities: string[];
  radiusTargeting: boolean;
  radiusKm?: number;
  radiusLat?: number;
  radiusLng?: number;
  ageRange: [number, number];
  gender: 'all' | 'male' | 'female';
  languages: string[];
  estimatedReach: number;
}

export interface ScheduleData {
  startDate: string;
  endDate: string;
  daypart: 'all-day' | 'commute' | 'evenings' | 'custom';
  customHours?: { start: string; end: string }[];
  timezone: string;
}

export interface BudgetData {
  type: 'total' | 'daily';
  amount: number;
  objective: 'awareness' | 'traffic';
  frequencyEnabled: boolean;
  frequencyCap: number;
  estimatedImpressions: number;
  estimatedClicks: number;
  estimatedCPM: number;
  estimatedCPC: number;
}

export interface CampaignData {
  id?: string;
  name: string;
  status: 'draft' | 'pending_review' | 'active' | 'paused' | 'completed';
  creative: CreativeData;
  targeting: TargetingData;
  schedule: ScheduleData;
  budget: BudgetData;
  createdAt?: string;
  updatedAt?: string;
}

// Actions
type CampaignAction =
  | { type: 'SET_CREATIVE'; payload: Partial<CreativeData> }
  | { type: 'SET_TARGETING'; payload: Partial<TargetingData> }
  | { type: 'SET_SCHEDULE'; payload: Partial<ScheduleData> }
  | { type: 'SET_BUDGET'; payload: Partial<BudgetData> }
  | { type: 'SET_CAMPAIGN_NAME'; payload: string }
  | { type: 'SET_CAMPAIGN_STATUS'; payload: CampaignData['status'] }
  | { type: 'LOAD_CAMPAIGN'; payload: CampaignData }
  | { type: 'RESET_CAMPAIGN' }
  | { type: 'UPDATE_ESTIMATED_REACH'; payload: number };

// Initial State
const initialCampaignData: CampaignData = {
  name: '',
  status: 'draft',
  creative: {
    file: null,
    fileName: '',
    fileSize: 0,
    fileType: '',
    landingUrl: '',
    ctaText: 'Learn More'
  },
  targeting: {
    cities: [],
    municipalities: [],
    radiusTargeting: false,
    ageRange: [18, 65],
    gender: 'all',
    languages: ['en'],
    estimatedReach: 0
  },
  schedule: {
    startDate: '',
    endDate: '',
    daypart: 'all-day',
    timezone: 'UTC'
  },
  budget: {
    type: 'total',
    amount: 0,
    objective: 'awareness',
    frequencyEnabled: true,
    frequencyCap: 3,
    estimatedImpressions: 0,
    estimatedClicks: 0,
    estimatedCPM: 2.5,
    estimatedCPC: 0.8
  }
};

// Reducer
function campaignReducer(state: CampaignData, action: CampaignAction): CampaignData {
  switch (action.type) {
    case 'SET_CREATIVE':
      return {
        ...state,
        creative: { ...state.creative, ...action.payload }
      };
    case 'SET_TARGETING':
      return {
        ...state,
        targeting: { ...state.targeting, ...action.payload }
      };
    case 'SET_SCHEDULE':
      return {
        ...state,
        schedule: { ...state.schedule, ...action.payload }
      };
    case 'SET_BUDGET':
      return {
        ...state,
        budget: { ...state.budget, ...action.payload }
      };
    case 'SET_CAMPAIGN_NAME':
      return {
        ...state,
        name: action.payload
      };
    case 'SET_CAMPAIGN_STATUS':
      return {
        ...state,
        status: action.payload
      };
    case 'LOAD_CAMPAIGN':
      return action.payload;
    case 'RESET_CAMPAIGN':
      return initialCampaignData;
    case 'UPDATE_ESTIMATED_REACH':
      return {
        ...state,
        targeting: {
          ...state.targeting,
          estimatedReach: action.payload
        }
      };
    default:
      return state;
  }
}

// Context
interface CampaignContextType {
  campaignData: CampaignData;
  dispatch: React.Dispatch<CampaignAction>;
  completedSteps: string[];
  setCompletedSteps: (steps: string[]) => void;
  isStepCompleted: (step: string) => boolean;
  markStepCompleted: (step: string) => void;
  validateStep: (step: string) => boolean;
  calculateEstimates: () => void;
}

const CampaignContext = createContext<CampaignContextType | undefined>(undefined);

// Provider
interface CampaignProviderProps {
  children: ReactNode;
}

export function CampaignProvider({ children }: CampaignProviderProps) {
  const [campaignData, dispatch] = useReducer(campaignReducer, initialCampaignData);
  const [completedSteps, setCompletedSteps] = useState<string[]>([]);

  const isStepCompleted = (step: string) => completedSteps.includes(step);

  const markStepCompleted = (step: string) => {
    if (!completedSteps.includes(step)) {
      setCompletedSteps(prev => [...prev, step]);
    }
  };

  const validateStep = (step: string): boolean => {
    switch (step) {
      case 'ad-creative-upload':
        return !!(
          campaignData.creative.file &&
          campaignData.creative.landingUrl &&
          campaignData.creative.ctaText
        );
      case 'targeting':
        return campaignData.targeting.cities.length > 0;
      case 'schedule-budget':
        return !!(
          campaignData.schedule.startDate &&
          campaignData.schedule.endDate &&
          campaignData.budget.amount > 0
        );
      case 'review-policy':
        return validateStep('ad-creative-upload') && 
               validateStep('targeting') && 
               validateStep('schedule-budget');
      default:
        return false;
    }
  };

  const calculateEstimates = () => {
    const { cities } = campaignData.targeting;
    const { amount, objective } = campaignData.budget;

    // Mock calculation based on selected cities and budget
    const baseReachPerCity = 150000;
    const estimatedReach = cities.length * baseReachPerCity;

    const cpmRate = objective === 'awareness' ? 2.5 : 3.5;
    const cpcRate = objective === 'traffic' ? 0.8 : 1.2;

    const estimatedImpressions = objective === 'awareness' ? 
      Math.floor((amount / cpmRate) * 1000) : 
      Math.floor(amount / cpcRate * 10); // Rough impression estimate for traffic campaigns

    const estimatedClicks = objective === 'traffic' ? 
      Math.floor(amount / cpcRate) : 
      Math.floor(estimatedImpressions * 0.028); // 2.8% CTR

    dispatch({ type: 'UPDATE_ESTIMATED_REACH', payload: estimatedReach });
    dispatch({ 
      type: 'SET_BUDGET', 
      payload: { 
        estimatedImpressions, 
        estimatedClicks,
        estimatedCPM: cpmRate,
        estimatedCPC: cpcRate
      } 
    });
  };

  return (
    <CampaignContext.Provider value={{
      campaignData,
      dispatch,
      completedSteps,
      setCompletedSteps,
      isStepCompleted,
      markStepCompleted,
      validateStep,
      calculateEstimates
    }}>
      {children}
    </CampaignContext.Provider>
  );
}

// Hook
export function useCampaign() {
  const context = useContext(CampaignContext);
  if (context === undefined) {
    throw new Error('useCampaign must be used within a CampaignProvider');
  }
  return context;
}