import { useState } from 'react';
import { ArrowUp, ArrowDown, Eye, MousePointer, TrendingUp, DollarSign, MapPin, Calendar, MoreHorizontal, Pause, Play, Edit, Trash2 } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from './ui/dropdown-menu';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';
import { AdvertiserFlowLayout } from './AdvertiserFlowLayout';
import { Screen, User } from '../App';

interface CampaignDashboardProps {
  user: User | null;
  onNavigate: (screen: Screen) => void;
  onLogout: () => void;
}

// Mock campaign data
const CAMPAIGN_DATA = {
  id: 'camp_001',
  name: 'Brand Awareness Q1 2024',
  status: 'active',
  startDate: '2024-02-01',
  endDate: '2024-02-15',
  budget: 500,
  spent: 127.50,
  impressions: 45830,
  clicks: 1274,
  ctr: 2.78,
  cpm: 2.78,
  cpc: 0.10,
  cities: ['Nairobi', 'Accra', 'Cape Town']
};

// Mock performance data for charts
const PERFORMANCE_DATA = [
  { date: '2/1', impressions: 3200, clicks: 89, spend: 8.90 },
  { date: '2/2', impressions: 4100, clicks: 114, spend: 11.40 },
  { date: '2/3', impressions: 3800, clicks: 95, spend: 10.54 },
  { date: '2/4', impressions: 5200, clicks: 156, spend: 14.46 },
  { date: '2/5', impressions: 4600, clicks: 138, spend: 12.78 },
  { date: '2/6', impressions: 3900, clicks: 109, spend: 10.84 },
  { date: '2/7', impressions: 4800, clicks: 144, spend: 13.34 },
];

const CITY_BREAKDOWN = [
  { city: 'Nairobi', impressions: 18330, clicks: 520, spend: 51.00, ctr: 2.84 },
  { city: 'Accra', impressions: 15200, clicks: 380, spend: 42.18, ctr: 2.50 },
  { city: 'Cape Town', impressions: 12300, clicks: 374, spend: 34.32, ctr: 3.04 },
];

export function CampaignDashboard({ user, onNavigate, onLogout }: CampaignDashboardProps) {
  const [timeRange, setTimeRange] = useState('7d');
  const [selectedMetric, setSelectedMetric] = useState('impressions');

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'active':
        return <Badge className="bg-green-100 text-green-800 border-green-200">Active</Badge>;
      case 'paused':
        return <Badge variant="secondary">Paused</Badge>;
      case 'completed':
        return <Badge variant="outline">Completed</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2
    }).format(amount);
  };

  const formatPercentage = (value: number) => {
    return `${value.toFixed(2)}%`;
  };

  const MetricCard = ({ 
    title, 
    value, 
    change, 
    changeType, 
    icon: Icon, 
    format = 'number' 
  }: { 
    title: string; 
    value: number; 
    change: number; 
    changeType: 'increase' | 'decrease'; 
    icon: any; 
    format?: 'number' | 'currency' | 'percentage' 
  }) => {
    const formatValue = (val: number) => {
      switch (format) {
        case 'currency':
          return formatCurrency(val);
        case 'percentage':
          return formatPercentage(val);
        default:
          return val.toLocaleString();
      }
    };

    return (
      <Card className="p-6 rounded-2xl shadow-sm">
        <div className="flex items-center justify-between">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <Icon className="w-4 h-4 text-muted-foreground" />
              <p className="text-sm font-medium text-muted-foreground">{title}</p>
            </div>
            <p className="text-2xl font-bold">{formatValue(value)}</p>
            <div className="flex items-center gap-1">
              {changeType === 'increase' ? (
                <ArrowUp className="w-3 h-3 text-green-600" />
              ) : (
                <ArrowDown className="w-3 h-3 text-red-600" />
              )}
              <span className={`text-xs ${changeType === 'increase' ? 'text-green-600' : 'text-red-600'}`}>
                {Math.abs(change)}% vs last period
              </span>
            </div>
          </div>
        </div>
      </Card>
    );
  };

  return (
    <AdvertiserFlowLayout
      user={user}
      currentStep="campaign-dashboard"
      completedSteps={['ad-creative-upload', 'targeting', 'schedule-budget', 'review-policy']}
      onNavigate={onNavigate}
      onLogout={onLogout}
      showBackButton={false}
    >
      <div className="space-y-6">
        {/* Campaign Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div className="space-y-2">
            <div className="flex items-center gap-3">
              <h1 className="text-2xl font-bold">{CAMPAIGN_DATA.name}</h1>
              {getStatusBadge(CAMPAIGN_DATA.status)}
            </div>
            <div className="flex items-center gap-4 text-sm text-muted-foreground">
              <div className="flex items-center gap-1">
                <Calendar className="w-4 h-4" />
                <span>{new Date(CAMPAIGN_DATA.startDate).toLocaleDateString()} - {new Date(CAMPAIGN_DATA.endDate).toLocaleDateString()}</span>
              </div>
              <div className="flex items-center gap-1">
                <MapPin className="w-4 h-4" />
                <span>{CAMPAIGN_DATA.cities.join(', ')}</span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <Select value={timeRange} onValueChange={setTimeRange}>
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="1d">Last 24h</SelectItem>
                <SelectItem value="7d">Last 7 days</SelectItem>
                <SelectItem value="30d">Last 30 days</SelectItem>
                <SelectItem value="all">All time</SelectItem>
              </SelectContent>
            </Select>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm">
                  <MoreHorizontal className="w-4 h-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem>
                  <Play className="w-4 h-4 mr-2" />
                  Resume Campaign
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <Pause className="w-4 h-4 mr-2" />
                  Pause Campaign
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <Edit className="w-4 h-4 mr-2" />
                  Edit Campaign
                </DropdownMenuItem>
                <DropdownMenuItem className="text-destructive">
                  <Trash2 className="w-4 h-4 mr-2" />
                  Delete Campaign
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            <Button onClick={() => onNavigate('report-scheduling')} className="rounded-2xl">
              Schedule Reports
            </Button>
          </div>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <MetricCard
            title="Impressions"
            value={CAMPAIGN_DATA.impressions}
            change={12.5}
            changeType="increase"
            icon={Eye}
          />
          <MetricCard
            title="Clicks"
            value={CAMPAIGN_DATA.clicks}
            change={8.3}
            changeType="increase"
            icon={MousePointer}
          />
          <MetricCard
            title="CTR"
            value={CAMPAIGN_DATA.ctr}
            change={3.1}
            changeType="increase"
            icon={TrendingUp}
            format="percentage"
          />
          <MetricCard
            title="Spend"
            value={CAMPAIGN_DATA.spent}
            change={15.2}
            changeType="increase"
            icon={DollarSign}
            format="currency"
          />
        </div>

        {/* Performance Chart */}
        <Card className="p-6 rounded-2xl shadow-sm">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold">Performance Over Time</h3>
              <Select value={selectedMetric} onValueChange={setSelectedMetric}>
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="impressions">Impressions</SelectItem>
                  <SelectItem value="clicks">Clicks</SelectItem>
                  <SelectItem value="spend">Spend</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={PERFORMANCE_DATA}>
                  <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                  <XAxis 
                    dataKey="date" 
                    axisLine={false}
                    tickLine={false}
                    className="text-muted-foreground"
                  />
                  <YAxis 
                    axisLine={false}
                    tickLine={false}
                    className="text-muted-foreground"
                  />
                  <Tooltip 
                    contentStyle={{
                      backgroundColor: 'hsl(var(--card))',
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '8px'
                    }}
                  />
                  <Line 
                    type="monotone" 
                    dataKey={selectedMetric} 
                    stroke="hsl(var(--primary))" 
                    strokeWidth={2}
                    dot={{ fill: 'hsl(var(--primary))', strokeWidth: 2, r: 4 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </Card>

        {/* City Breakdown */}
        <Card className="p-6 rounded-2xl shadow-sm">
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Performance by City</h3>
            
            <div className="space-y-4">
              {CITY_BREAKDOWN.map((city) => (
                <div key={city.city} className="p-4 bg-secondary/30 rounded-xl">
                  <div className="flex items-center justify-between mb-3">
                    <h4 className="font-medium">{city.city}</h4>
                    <Badge variant="outline">{formatPercentage(city.ctr)} CTR</Badge>
                  </div>
                  
                  <div className="grid grid-cols-3 gap-4 text-sm">
                    <div>
                      <p className="text-muted-foreground">Impressions</p>
                      <p className="font-semibold">{city.impressions.toLocaleString()}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Clicks</p>
                      <p className="font-semibold">{city.clicks.toLocaleString()}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Spend</p>
                      <p className="font-semibold">{formatCurrency(city.spend)}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </Card>

        {/* Creative Performance */}
        <Card className="p-6 rounded-2xl shadow-sm">
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Creative Performance</h3>
            
            <div className="flex items-center gap-6 p-4 bg-secondary/30 rounded-xl">
              <div className="w-20 h-16 bg-muted rounded-lg flex items-center justify-center">
                <Eye className="w-6 h-6 text-muted-foreground" />
              </div>
              
              <div className="flex-1">
                <h4 className="font-medium">brand-campaign.jpg</h4>
                <p className="text-sm text-muted-foreground">Active since Feb 1, 2024</p>
              </div>
              
              <div className="grid grid-cols-4 gap-6 text-center">
                <div>
                  <p className="text-sm text-muted-foreground">Impressions</p>
                  <p className="font-semibold">{CAMPAIGN_DATA.impressions.toLocaleString()}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Clicks</p>
                  <p className="font-semibold">{CAMPAIGN_DATA.clicks.toLocaleString()}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">CTR</p>
                  <p className="font-semibold">{formatPercentage(CAMPAIGN_DATA.ctr)}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">CPC</p>
                  <p className="font-semibold">{formatCurrency(CAMPAIGN_DATA.cpc)}</p>
                </div>
              </div>
            </div>
          </div>
        </Card>

        {/* Quick Actions */}
        <div className="flex flex-wrap gap-3">
          <Button variant="outline" onClick={() => onNavigate('ad-creative-upload')} className="rounded-2xl">
            Create New Campaign
          </Button>
          <Button variant="outline" onClick={() => onNavigate('analytics')} className="rounded-2xl">
            View Advanced Analytics
          </Button>
          <Button variant="outline" onClick={() => onNavigate('dashboard')} className="rounded-2xl">
            Back to Main Dashboard
          </Button>
        </div>
      </div>
    </AdvertiserFlowLayout>
  );
}