import { useState } from 'react';
import { Upload, Image, Video, AlertCircle, Eye, ExternalLink } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Alert, AlertDescription } from './ui/alert';
import { AdvertiserFlowLayout } from './AdvertiserFlowLayout';
import { Screen, User } from '../App';

interface AdCreativeUploadProps {
  user: User | null;
  onNavigate: (screen: Screen) => void;
  onLogout: () => void;
}

export function AdCreativeUpload({ user, onNavigate, onLogout }: AdCreativeUploadProps) {
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [landingUrl, setLandingUrl] = useState('');
  const [ctaText, setCtaText] = useState('Learn More');
  const [dragActive, setDragActive] = useState(false);
  const [errors, setErrors] = useState<string[]>([]);

  const handleFileUpload = (file: File) => {
    const errors: string[] = [];
    
    // Validate file type
    const validTypes = ['image/jpeg', 'image/png', 'image/webp', 'video/mp4', 'video/webm'];
    if (!validTypes.includes(file.type)) {
      errors.push('Please upload a valid image (JPEG, PNG, WebP) or video (MP4, WebM) file');
    }
    
    // Validate file size (10MB max)
    if (file.size > 10 * 1024 * 1024) {
      errors.push('File size must be less than 10MB');
    }
    
    // Validate video duration (would need actual video analysis in production)
    if (file.type.startsWith('video/')) {
      // Mock validation - in production you'd analyze the video duration
      // For now, we'll just show a warning
    }
    
    setErrors(errors);
    
    if (errors.length === 0) {
      setUploadedFile(file);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragActive(false);
    
    const files = Array.from(e.dataTransfer.files);
    if (files[0]) {
      handleFileUpload(files[0]);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFileUpload(e.target.files[0]);
    }
  };

  const validateUrl = (url: string) => {
    try {
      new URL(url);
      return true;
    } catch {
      return false;
    }
  };

  const canProceed = uploadedFile && landingUrl && validateUrl(landingUrl) && ctaText.trim();

  const handleNext = () => {
    if (canProceed) {
      onNavigate('targeting');
    }
  };

  return (
    <AdvertiserFlowLayout
      user={user}
      currentStep="ad-creative-upload"
      completedSteps={[]}
      onNavigate={onNavigate}
      onLogout={onLogout}
      showBackButton={false}
    >
      <div className="space-y-8">
        {/* Upload Section */}
        <Card className="p-6 rounded-2xl shadow-sm">
          <div className="space-y-4">
            <div>
              <h2 className="text-lg font-semibold">Upload Creative</h2>
              <p className="text-sm text-muted-foreground">
                Upload your ad image or video. Supported formats: JPEG, PNG, WebP, MP4, WebM
              </p>
            </div>

            <div
              className={`
                border-2 border-dashed rounded-2xl p-8 text-center transition-colors cursor-pointer
                ${dragActive ? 'border-primary bg-secondary/50' : 'border-muted-foreground/30'}
                ${uploadedFile ? 'border-primary bg-secondary/20' : ''}
              `}
              onDragOver={(e) => {
                e.preventDefault();
                setDragActive(true);
              }}
              onDragLeave={() => setDragActive(false)}
              onDrop={handleDrop}
              onClick={() => document.getElementById('file-upload')?.click()}
            >
              {uploadedFile ? (
                <div className="space-y-4">
                  <div className="flex items-center justify-center w-16 h-16 mx-auto bg-primary/10 rounded-full">
                    {uploadedFile.type.startsWith('video/') ? (
                      <Video className="w-8 h-8 text-primary" />
                    ) : (
                      <Image className="w-8 h-8 text-primary" />
                    )}
                  </div>
                  <div>
                    <p className="font-medium">{uploadedFile.name}</p>
                    <p className="text-sm text-muted-foreground">
                      {(uploadedFile.size / 1024 / 1024).toFixed(2)}MB • {uploadedFile.type}
                    </p>
                  </div>
                  <Button variant="outline" size="sm" onClick={(e) => {
                    e.stopPropagation();
                    setUploadedFile(null);
                  }}>
                    Remove
                  </Button>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="flex items-center justify-center w-16 h-16 mx-auto bg-muted rounded-full">
                    <Upload className="w-8 h-8 text-muted-foreground" />
                  </div>
                  <div>
                    <p className="font-medium">Drop your creative here</p>
                    <p className="text-sm text-muted-foreground">
                      Or click to browse files
                    </p>
                  </div>
                  <div className="text-xs text-muted-foreground space-y-1">
                    <p>• Max file size: 10MB</p>
                    <p>• Video duration: ≤30 seconds</p>
                    <p>• Recommended aspect ratio: 16:9 or 1:1</p>
                  </div>
                </div>
              )}
              
              <input
                id="file-upload"
                type="file"
                className="hidden"
                accept="image/*,video/*"
                onChange={handleFileSelect}
              />
            </div>

            {errors.length > 0 && (
              <Alert className="border-destructive/20 bg-destructive/5">
                <AlertCircle className="h-4 w-4 text-destructive" />
                <AlertDescription className="text-destructive">
                  <ul className="list-disc list-inside space-y-1">
                    {errors.map((error, index) => (
                      <li key={index}>{error}</li>
                    ))}
                  </ul>
                </AlertDescription>
              </Alert>
            )}
          </div>
        </Card>

        {/* Landing Page & CTA */}
        <Card className="p-6 rounded-2xl shadow-sm">
          <div className="space-y-4">
            <div>
              <h2 className="text-lg font-semibold">Landing Page & Call-to-Action</h2>
              <p className="text-sm text-muted-foreground">
                Configure where users go when they click your ad
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="landing-url">Landing Page URL *</Label>
                <div className="relative">
                  <Input
                    id="landing-url"
                    type="url"
                    placeholder="https://example.com/landing"
                    value={landingUrl}
                    onChange={(e) => setLandingUrl(e.target.value)}
                    className={`pr-10 ${landingUrl && !validateUrl(landingUrl) ? 'border-destructive' : ''}`}
                  />
                  <ExternalLink className="absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                </div>
                {landingUrl && !validateUrl(landingUrl) && (
                  <p className="text-xs text-destructive">Please enter a valid URL</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="cta-text">Call-to-Action Text *</Label>
                <Input
                  id="cta-text"
                  placeholder="Learn More"
                  value={ctaText}
                  onChange={(e) => setCtaText(e.target.value)}
                  maxLength={25}
                />
                <p className="text-xs text-muted-foreground">
                  {ctaText.length}/25 characters
                </p>
              </div>
            </div>
          </div>
        </Card>

        {/* Preview Section */}
        {uploadedFile && (
          <Card className="p-6 rounded-2xl shadow-sm">
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <Eye className="w-5 h-5 text-primary" />
                <h2 className="text-lg font-semibold">Ad Preview</h2>
              </div>
              
              <div className="bg-gray-100 rounded-2xl p-6">
                <div className="max-w-sm mx-auto bg-white rounded-xl shadow-lg overflow-hidden">
                  <div className="aspect-video bg-muted flex items-center justify-center">
                    {uploadedFile.type.startsWith('video/') ? (
                      <Video className="w-12 h-12 text-muted-foreground" />
                    ) : (
                      <Image className="w-12 h-12 text-muted-foreground" />
                    )}
                  </div>
                  <div className="p-4">
                    <p className="text-sm text-gray-600 mb-3">Sponsored</p>
                    <div className="flex items-center justify-between">
                      <p className="text-sm">Click to visit landing page</p>
                      <Button size="sm" className="rounded-xl">
                        {ctaText || 'Learn More'}
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
              
              <p className="text-xs text-muted-foreground text-center">
                Preview shows how your ad will appear in ride-hailing apps
              </p>
            </div>
          </Card>
        )}

        {/* Navigation */}
        <div className="flex justify-between">
          <div></div>
          <Button 
            onClick={handleNext}
            disabled={!canProceed}
            className="rounded-2xl"
          >
            Continue to Targeting
          </Button>
        </div>
      </div>
    </AdvertiserFlowLayout>
  );
}