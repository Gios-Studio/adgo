import { useState } from 'react';
import { Layout } from './Layout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Progress } from './ui/progress';
import { 
  LineChart, 
  Line, 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  BarChart,
  Bar
} from 'recharts';
import { 
  Eye, 
  MousePointer, 
  DollarSign, 
  TrendingUp, 
  TrendingDown, 
  AlertTriangle,
  CheckCircle,
  Clock,
  Plus
} from 'lucide-react';
import type { Screen, User } from '../App';

interface DashboardProps {
  user: User | null;
  onNavigate: (screen: Screen) => void;
  onLogout: () => void;
}

// Mock data
const performanceData = [
  { date: 'Jan 1', impressions: 2400, clicks: 240, spend: 120 },
  { date: 'Jan 2', impressions: 1398, clicks: 221, spend: 110 },
  { date: 'Jan 3', impressions: 9800, clicks: 980, spend: 490 },
  { date: 'Jan 4', impressions: 3908, clicks: 390, spend: 195 },
  { date: 'Jan 5', impressions: 4800, clicks: 480, spend: 240 },
  { date: 'Jan 6', impressions: 3800, clicks: 456, spend: 228 },
  { date: 'Jan 7', impressions: 4300, clicks: 516, spend: 258 },
];

const geoData = [
  { city: 'New York', impressions: 15420, ctr: 4.2 },
  { city: 'Los Angeles', impressions: 12300, ctr: 3.8 },
  { city: 'Chicago', impressions: 8900, ctr: 4.5 },
  { city: 'Houston', impressions: 7600, ctr: 3.9 },
  { city: 'Phoenix', impressions: 5400, ctr: 4.1 },
];

export function Dashboard({ user, onNavigate, onLogout }: DashboardProps) {
  const [timeRange, setTimeRange] = useState('7d');

  return (
    <Layout user={user} currentScreen="dashboard" onNavigate={onNavigate} onLogout={onLogout}>
      {/* Header */}
      <div className="border-b border-border bg-background px-6 py-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">Dashboard</h1>
            <p className="text-muted-foreground">Welcome back, {user?.name}</p>
          </div>
          
          <div className="flex items-center space-x-3">
            <Button onClick={() => onNavigate('ad-creative-upload')} variant="default">
              <Plus className="size-4 mr-2" />
              Create Campaign
            </Button>
            <Button onClick={() => onNavigate('ad-upload')} variant="outline">
              Quick Ad Upload
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-auto p-6 space-y-6">
        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Impressions</CardTitle>
              <Eye className="size-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">45.2K</div>
              <div className="flex items-center text-xs text-muted-foreground">
                <TrendingUp className="size-3 mr-1 text-green-500" />
                +12.5% from last week
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Clicks</CardTitle>
              <MousePointer className="size-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">3.8K</div>
              <div className="flex items-center text-xs text-muted-foreground">
                <TrendingUp className="size-3 mr-1 text-green-500" />
                +8.3% from last week
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">CTR</CardTitle>
              <TrendingUp className="size-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">4.2%</div>
              <div className="flex items-center text-xs text-muted-foreground">
                <TrendingDown className="size-3 mr-1 text-red-500" />
                -0.5% from last week
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Spend</CardTitle>
              <DollarSign className="size-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">$1,234</div>
              <div className="flex items-center text-xs text-muted-foreground">
                <TrendingUp className="size-3 mr-1 text-green-500" />
                +15.2% from last week
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Performance Chart */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Ad Performance</CardTitle>
                  <CardDescription>Daily impressions and clicks over time</CardDescription>
                </div>
                <Tabs value={timeRange} onValueChange={setTimeRange} className="w-auto">
                  <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="7d">7D</TabsTrigger>
                    <TabsTrigger value="30d">30D</TabsTrigger>
                    <TabsTrigger value="90d">90D</TabsTrigger>
                  </TabsList>
                </Tabs>
              </div>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <AreaChart data={performanceData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip />
                  <Area 
                    type="monotone" 
                    dataKey="impressions" 
                    stackId="1"
                    stroke="#2d5016" 
                    fill="#2d5016" 
                    fillOpacity={0.6}
                  />
                  <Area 
                    type="monotone" 
                    dataKey="clicks" 
                    stackId="2"
                    stroke="#4a7c2a" 
                    fill="#4a7c2a" 
                    fillOpacity={0.6}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Notifications & Alerts */}
          <Card>
            <CardHeader>
              <CardTitle>Notifications</CardTitle>
              <CardDescription>Recent updates and alerts</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-start space-x-3">
                <AlertTriangle className="size-5 text-yellow-500 mt-0.5" />
                <div className="space-y-1">
                  <p className="text-sm font-medium">Campaign budget low</p>
                  <p className="text-xs text-muted-foreground">
                    "Summer Sale" campaign has 10% budget remaining
                  </p>
                  <Badge variant="outline" className="text-xs">
                    2 hours ago
                  </Badge>
                </div>
              </div>
              
              <div className="flex items-start space-x-3">
                <CheckCircle className="size-5 text-green-500 mt-0.5" />
                <div className="space-y-1">
                  <p className="text-sm font-medium">Ad approved</p>
                  <p className="text-xs text-muted-foreground">
                    Your "Holiday Special" ad has been approved
                  </p>
                  <Badge variant="outline" className="text-xs">
                    4 hours ago
                  </Badge>
                </div>
              </div>
              
              <div className="flex items-start space-x-3">
                <Clock className="size-5 text-blue-500 mt-0.5" />
                <div className="space-y-1">
                  <p className="text-sm font-medium">Campaign scheduled</p>
                  <p className="text-xs text-muted-foreground">
                    "Back to School" will start tomorrow at 9 AM
                  </p>
                  <Badge variant="outline" className="text-xs">
                    1 day ago
                  </Badge>
                </div>
              </div>
              
              <Button variant="outline" size="sm" className="w-full">
                View All Notifications
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Geographic Performance */}
        <Card>
          <CardHeader>
            <CardTitle>Geographic Performance</CardTitle>
            <CardDescription>Top performing cities by impressions and CTR</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={geoData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="city" />
                <YAxis yAxisId="left" />
                <YAxis yAxisId="right" orientation="right" />
                <Tooltip />
                <Bar yAxisId="left" dataKey="impressions" fill="#2d5016" />
                <Line yAxisId="right" dataKey="ctr" stroke="#4a7c2a" strokeWidth={2} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Recent Campaigns */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Recent Campaigns</CardTitle>
                <CardDescription>Your latest advertising campaigns</CardDescription>
              </div>
              <Button variant="outline" onClick={() => onNavigate('campaigns')}>
                View All
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 border border-border rounded-lg">
                <div className="space-y-1">
                  <p className="font-medium">Summer Sale Campaign</p>
                  <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                    <span>1.2K impressions</span>
                    <span>•</span>
                    <span>4.8% CTR</span>
                    <span>•</span>
                    <span>$124 spent</span>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Badge variant="secondary">Active</Badge>
                  <div className="w-20">
                    <Progress value={75} className="h-2" />
                    <p className="text-xs text-muted-foreground mt-1">75% budget</p>
                  </div>
                </div>
              </div>
              
              <div className="flex items-center justify-between p-4 border border-border rounded-lg">
                <div className="space-y-1">
                  <p className="font-medium">Holiday Special</p>
                  <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                    <span>856 impressions</span>
                    <span>•</span>
                    <span>3.2% CTR</span>
                    <span>•</span>
                    <span>$89 spent</span>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Badge variant="outline">Scheduled</Badge>
                  <div className="w-20">
                    <Progress value={0} className="h-2" />
                    <p className="text-xs text-muted-foreground mt-1">Starts tomorrow</p>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}