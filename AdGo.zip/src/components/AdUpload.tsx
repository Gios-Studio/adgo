import { useState } from 'react';
import { Layout } from './Layout';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Calendar } from './ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from './ui/popover';
import { Checkbox } from './ui/checkbox';
import { Slider } from './ui/slider';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { Progress } from './ui/progress';
import { 
  Upload, 
  Image as ImageIcon, 
  Video, 
  Calendar as CalendarIcon,
  Target,
  MapPin,
  Users,
  DollarSign,
  Eye,
  CheckCircle,
  ArrowRight
} from 'lucide-react';
import type { Screen, User } from '../App';

interface AdUploadProps {
  user: User | null;
  onNavigate: (screen: Screen) => void;
  onLogout: () => void;
}

export function AdUpload({ user, onNavigate, onLogout }: AdUploadProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [dragActive, setDragActive] = useState(false);
  const [startDate, setStartDate] = useState<Date>();
  const [endDate, setEndDate] = useState<Date>();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  
  const [campaignData, setCampaignData] = useState({
    name: '',
    description: '',
    targetCity: '',
    ageRange: [18, 65],
    interests: [] as string[],
    budget: 100,
    bidType: 'cpm',
    demographics: [] as string[]
  });

  const steps = [
    { id: 0, title: 'Upload Creative', description: 'Upload your ad image or video' },
    { id: 1, title: 'Campaign Details', description: 'Set up your campaign information' },
    { id: 2, title: 'Targeting', description: 'Define your target audience' },
    { id: 3, title: 'Budget & Schedule', description: 'Set budget and schedule' },
    { id: 4, title: 'Review', description: 'Review and launch your campaign' }
  ];

  const cities = ['New York', 'Los Angeles', 'Chicago', 'Houston', 'Phoenix', 'Philadelphia', 'San Antonio', 'San Diego'];
  const interests = ['Technology', 'Fashion', 'Sports', 'Travel', 'Food', 'Health', 'Entertainment', 'Business', 'Education', 'Automotive'];
  const demographics = ['18-24', '25-34', '35-44', '45-54', '55-64', '65+'];

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      setUploadedFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setUploadedFile(e.target.files[0]);
    }
  };

  const handleInterestToggle = (interest: string) => {
    setCampaignData(prev => ({
      ...prev,
      interests: prev.interests.includes(interest)
        ? prev.interests.filter(i => i !== interest)
        : [...prev.interests, interest]
    }));
  };

  const handleDemographicToggle = (demo: string) => {
    setCampaignData(prev => ({
      ...prev,
      demographics: prev.demographics.includes(demo)
        ? prev.demographics.filter(d => d !== demo)
        : [...prev.demographics, demo]
    }));
  };

  const handleSubmit = async () => {
    setIsSubmitting(true);
    
    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSuccess(true);
    }, 3000);
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const nextStep = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    }
  };

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  if (isSuccess) {
    return (
      <Layout user={user} currentScreen="ad-upload" onNavigate={onNavigate} onLogout={onLogout}>
        <div className="flex-1 flex items-center justify-center p-6">
          <Card className="w-full max-w-md text-center">
            <CardContent className="pt-6">
              <div className="size-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="size-8 text-primary" />
              </div>
              <h2 className="text-2xl font-bold mb-2">Campaign Created Successfully!</h2>
              <p className="text-muted-foreground mb-6">
                Your ad has been submitted for review and will be active once approved.
              </p>
              <div className="space-y-2">
                <Button className="w-full" onClick={() => onNavigate('campaigns')}>
                  View My Campaigns
                </Button>
                <Button variant="outline" className="w-full" onClick={() => {
                  setIsSuccess(false);
                  setCurrentStep(0);
                  setUploadedFile(null);
                  setCampaignData({
                    name: '',
                    description: '',
                    targetCity: '',
                    ageRange: [18, 65],
                    interests: [],
                    budget: 100,
                    bidType: 'cpm',
                    demographics: []
                  });
                }}>
                  Create Another Ad
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </Layout>
    );
  }

  return (
    <Layout user={user} currentScreen="ad-upload" onNavigate={onNavigate} onLogout={onLogout}>
      {/* Header */}
      <div className="border-b border-border bg-background px-6 py-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">Create New Campaign</h1>
            <p className="text-muted-foreground">Step {currentStep + 1} of {steps.length}</p>
          </div>
          
          <div className="flex items-center space-x-2">
            <Progress value={(currentStep / (steps.length - 1)) * 100} className="w-32" />
            <span className="text-sm text-muted-foreground">{Math.round((currentStep / (steps.length - 1)) * 100)}%</span>
          </div>
        </div>
      </div>

      {/* Step Navigation */}
      <div className="border-b border-border bg-secondary/30 px-6 py-3">
        <div className="flex items-center space-x-8 overflow-x-auto">
          {steps.map((step, index) => (
            <div key={step.id} className="flex items-center space-x-2 whitespace-nowrap">
              <div className={`size-8 rounded-full flex items-center justify-center text-sm ${
                index <= currentStep 
                  ? 'bg-primary text-primary-foreground' 
                  : 'bg-muted text-muted-foreground'
              }`}>
                {index < currentStep ? <CheckCircle className="size-4" /> : index + 1}
              </div>
              <div className="hidden md:block">
                <p className={`text-sm font-medium ${
                  index <= currentStep ? 'text-foreground' : 'text-muted-foreground'
                }`}>
                  {step.title}
                </p>
              </div>
              {index < steps.length - 1 && (
                <ArrowRight className="size-4 text-muted-foreground hidden lg:block" />
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-auto p-6">
        <div className="max-w-4xl mx-auto">
          {/* Step 0: Upload Creative */}
          {currentStep === 0 && (
            <Card>
              <CardHeader>
                <CardTitle>Upload Your Creative</CardTitle>
                <CardDescription>
                  Upload an image or video for your advertisement. Supported formats: JPG, PNG, MP4, MOV
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div
                  className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
                    dragActive 
                      ? 'border-primary bg-primary/5' 
                      : 'border-border hover:border-primary/50'
                  }`}
                  onDragEnter={handleDrag}
                  onDragLeave={handleDrag}
                  onDragOver={handleDrag}
                  onDrop={handleDrop}
                >
                  {uploadedFile ? (
                    <div className="space-y-4">
                      <div className="size-16 bg-primary/10 rounded-lg flex items-center justify-center mx-auto">
                        {uploadedFile.type.startsWith('image/') ? (
                          <ImageIcon className="size-8 text-primary" />
                        ) : (
                          <Video className="size-8 text-primary" />
                        )}
                      </div>
                      <div>
                        <p className="font-medium">{uploadedFile.name}</p>
                        <p className="text-sm text-muted-foreground">
                          {(uploadedFile.size / 1024 / 1024).toFixed(2)} MB
                        </p>
                      </div>
                      <Button 
                        variant="outline" 
                        onClick={() => setUploadedFile(null)}
                      >
                        Remove File
                      </Button>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      <div className="size-16 bg-muted rounded-lg flex items-center justify-center mx-auto">
                        <Upload className="size-8 text-muted-foreground" />
                      </div>
                      <div>
                        <p className="text-lg font-medium">Drag and drop your file here</p>
                        <p className="text-muted-foreground">or click to browse</p>
                      </div>
                      <input
                        type="file"
                        accept="image/*,video/*"
                        onChange={handleFileChange}
                        className="hidden"
                        id="file-upload"
                      />
                      <Button asChild>
                        <label htmlFor="file-upload" className="cursor-pointer">
                          Choose File
                        </label>
                      </Button>
                    </div>
                  )}
                </div>
                
                <div className="flex justify-end">
                  <Button onClick={nextStep} disabled={!uploadedFile}>
                    Continue
                    <ArrowRight className="size-4 ml-2" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Step 1: Campaign Details */}
          {currentStep === 1 && (
            <Card>
              <CardHeader>
                <CardTitle>Campaign Details</CardTitle>
                <CardDescription>
                  Provide basic information about your advertising campaign
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="campaign-name">Campaign Name</Label>
                  <Input
                    id="campaign-name"
                    placeholder="e.g., Summer Sale 2025"
                    value={campaignData.name}
                    onChange={(e) => setCampaignData(prev => ({ ...prev, name: e.target.value }))}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="campaign-description">Description</Label>
                  <Textarea
                    id="campaign-description"
                    placeholder="Describe your campaign objectives and target audience..."
                    value={campaignData.description}
                    onChange={(e) => setCampaignData(prev => ({ ...prev, description: e.target.value }))}
                    rows={4}
                  />
                </div>
                
                <div className="flex justify-between">
                  <Button variant="outline" onClick={prevStep}>
                    Back
                  </Button>
                  <Button onClick={nextStep} disabled={!campaignData.name.trim()}>
                    Continue
                    <ArrowRight className="size-4 ml-2" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Step 2: Targeting */}
          {currentStep === 2 && (
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Target className="size-5 mr-2" />
                    Audience Targeting
                  </CardTitle>
                  <CardDescription>
                    Define who should see your advertisement
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Location Targeting */}
                  <div className="space-y-3">
                    <Label className="flex items-center">
                      <MapPin className="size-4 mr-2" />
                      Target City
                    </Label>
                    <Select value={campaignData.targetCity} onValueChange={(value) => 
                      setCampaignData(prev => ({ ...prev, targetCity: value }))
                    }>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a city" />
                      </SelectTrigger>
                      <SelectContent>
                        {cities.map(city => (
                          <SelectItem key={city} value={city}>{city}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Age Range */}
                  <div className="space-y-3">
                    <Label>Age Range: {campaignData.ageRange[0]} - {campaignData.ageRange[1]} years</Label>
                    <Slider
                      value={campaignData.ageRange}
                      onValueChange={(value) => setCampaignData(prev => ({ ...prev, ageRange: value }))}
                      max={80}
                      min={13}
                      step={1}
                      className="w-full"
                    />
                  </div>

                  <Separator />

                  {/* Demographics */}
                  <div className="space-y-3">
                    <Label className="flex items-center">
                      <Users className="size-4 mr-2" />
                      Demographics
                    </Label>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                      {demographics.map(demo => (
                        <div key={demo} className="flex items-center space-x-2">
                          <Checkbox
                            id={demo}
                            checked={campaignData.demographics.includes(demo)}
                            onCheckedChange={() => handleDemographicToggle(demo)}
                          />
                          <Label htmlFor={demo} className="text-sm">{demo}</Label>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Interests */}
                  <div className="space-y-3">
                    <Label>Interests</Label>
                    <div className="flex flex-wrap gap-2">
                      {interests.map(interest => (
                        <Badge
                          key={interest}
                          variant={campaignData.interests.includes(interest) ? "default" : "outline"}
                          className="cursor-pointer"
                          onClick={() => handleInterestToggle(interest)}
                        >
                          {interest}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <div className="flex justify-between">
                <Button variant="outline" onClick={prevStep}>
                  Back
                </Button>
                <Button onClick={nextStep} disabled={!campaignData.targetCity}>
                  Continue
                  <ArrowRight className="size-4 ml-2" />
                </Button>
              </div>
            </div>
          )}

          {/* Step 3: Budget & Schedule */}
          {currentStep === 3 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <DollarSign className="size-5 mr-2" />
                  Budget & Schedule
                </CardTitle>
                <CardDescription>
                  Set your budget and campaign schedule
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label>Daily Budget: ${campaignData.budget}</Label>
                      <Slider
                        value={[campaignData.budget]}
                        onValueChange={([value]) => setCampaignData(prev => ({ ...prev, budget: value }))}
                        max={1000}
                        min={10}
                        step={5}
                        className="w-full"
                      />
                      <p className="text-xs text-muted-foreground">
                        Estimated reach: {Math.round(campaignData.budget * 20)}-{Math.round(campaignData.budget * 35)} people/day
                      </p>
                    </div>
                    
                    <div className="space-y-2">
                      <Label>Bid Type</Label>
                      <Select value={campaignData.bidType} onValueChange={(value) => 
                        setCampaignData(prev => ({ ...prev, bidType: value }))
                      }>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="cpm">CPM (Cost per 1000 impressions)</SelectItem>
                          <SelectItem value="cpc">CPC (Cost per click)</SelectItem>
                          <SelectItem value="cpa">CPA (Cost per acquisition)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label>Start Date</Label>
                      <Popover>
                        <PopoverTrigger asChild>
                          <Button variant="outline" className="w-full justify-start">
                            <CalendarIcon className="size-4 mr-2" />
                            {startDate ? formatDate(startDate) : 'Select start date'}
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0">
                          <Calendar
                            mode="single"
                            selected={startDate}
                            onSelect={setStartDate}
                            initialFocus
                          />
                        </PopoverContent>
                      </Popover>
                    </div>
                    
                    <div className="space-y-2">
                      <Label>End Date (Optional)</Label>
                      <Popover>
                        <PopoverTrigger asChild>
                          <Button variant="outline" className="w-full justify-start">
                            <CalendarIcon className="size-4 mr-2" />
                            {endDate ? formatDate(endDate) : 'Select end date'}
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0">
                          <Calendar
                            mode="single"
                            selected={endDate}
                            onSelect={setEndDate}
                            initialFocus
                          />
                        </PopoverContent>
                      </Popover>
                    </div>
                  </div>
                </div>
                
                <div className="flex justify-between">
                  <Button variant="outline" onClick={prevStep}>
                    Back
                  </Button>
                  <Button onClick={nextStep} disabled={!startDate}>
                    Continue
                    <ArrowRight className="size-4 ml-2" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Step 4: Review */}
          {currentStep === 4 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Eye className="size-5 mr-2" />
                  Review Campaign
                </CardTitle>
                <CardDescription>
                  Review your campaign details before launching
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div>
                      <h4 className="font-medium mb-2">Campaign Details</h4>
                      <div className="space-y-1 text-sm">
                        <p><span className="text-muted-foreground">Name:</span> {campaignData.name}</p>
                        <p><span className="text-muted-foreground">Description:</span> {campaignData.description}</p>
                        <p><span className="text-muted-foreground">Creative:</span> {uploadedFile?.name}</p>
                      </div>
                    </div>
                    
                    <div>
                      <h4 className="font-medium mb-2">Targeting</h4>
                      <div className="space-y-1 text-sm">
                        <p><span className="text-muted-foreground">Location:</span> {campaignData.targetCity}</p>
                        <p><span className="text-muted-foreground">Age:</span> {campaignData.ageRange[0]}-{campaignData.ageRange[1]} years</p>
                        <p><span className="text-muted-foreground">Interests:</span> {campaignData.interests.join(', ') || 'None selected'}</p>
                        <p><span className="text-muted-foreground">Demographics:</span> {campaignData.demographics.join(', ') || 'None selected'}</p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    <div>
                      <h4 className="font-medium mb-2">Budget & Schedule</h4>
                      <div className="space-y-1 text-sm">
                        <p><span className="text-muted-foreground">Daily Budget:</span> ${campaignData.budget}</p>
                        <p><span className="text-muted-foreground">Bid Type:</span> {campaignData.bidType.toUpperCase()}</p>
                        <p><span className="text-muted-foreground">Start Date:</span> {startDate ? formatDate(startDate) : 'Not set'}</p>
                        <p><span className="text-muted-foreground">End Date:</span> {endDate ? formatDate(endDate) : 'Ongoing'}</p>
                      </div>
                    </div>
                    
                    <div className="p-4 bg-secondary/50 rounded-lg">
                      <h4 className="font-medium mb-2">Estimated Performance</h4>
                      <div className="space-y-1 text-sm">
                        <p><span className="text-muted-foreground">Daily Reach:</span> {Math.round(campaignData.budget * 20)}-{Math.round(campaignData.budget * 35)} people</p>
                        <p><span className="text-muted-foreground">Expected CTR:</span> 3.5-4.2%</p>
                        <p><span className="text-muted-foreground">Estimated Clicks:</span> {Math.round(campaignData.budget * 0.8)}-{Math.round(campaignData.budget * 1.5)} daily</p>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="flex justify-between">
                  <Button variant="outline" onClick={prevStep}>
                    Back
                  </Button>
                  <Button onClick={handleSubmit} disabled={isSubmitting}>
                    {isSubmitting ? 'Creating Campaign...' : 'Launch Campaign'}
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </Layout>
  );
}