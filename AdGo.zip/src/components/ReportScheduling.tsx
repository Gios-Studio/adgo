import { useState } from 'react';
import { Calendar, Mail, FileText, Download, Clock, Users, Crown, Lock, Check } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Label } from './ui/label';
import { Input } from './ui/input';
import { RadioGroup, RadioGroupItem } from './ui/radio-group';
import { Checkbox } from './ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Badge } from './ui/badge';
import { Textarea } from './ui/textarea';
import { Alert, AlertDescription } from './ui/alert';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from './ui/tooltip';
import { AdvertiserFlowLayout } from './AdvertiserFlowLayout';
import { Screen, User } from '../App';

interface ReportSchedulingProps {
  user: User | null;
  onNavigate: (screen: Screen) => void;
  onLogout: () => void;
}

const FREQUENCY_OPTIONS = [
  { id: 'daily', name: 'Daily', description: 'Every day at specified time', isPremium: false },
  { id: 'weekly', name: 'Weekly', description: 'Every Monday at specified time', isPremium: false },
  { id: 'monthly', name: 'Monthly', description: 'First day of each month', isPremium: false },
  { id: 'custom', name: 'Custom Schedule', description: 'Set specific days and times', isPremium: true },
];

const FORMAT_OPTIONS = [
  { id: 'pdf', name: 'PDF Report', description: 'Formatted visual report', icon: FileText },
  { id: 'csv', name: 'CSV Export', description: 'Raw data for analysis', icon: Download },
  { id: 'email', name: 'Email Summary', description: 'Key metrics via email', icon: Mail },
];

const METRIC_GROUPS = [
  {
    id: 'performance',
    name: 'Performance Metrics',
    description: 'Impressions, clicks, CTR, conversions',
    isPremium: false,
    metrics: ['impressions', 'clicks', 'ctr', 'spend']
  },
  {
    id: 'audience',
    name: 'Audience Insights',
    description: 'Demographics and geographic data',
    isPremium: true,
    metrics: ['age_breakdown', 'gender_breakdown', 'location_performance']
  },
  {
    id: 'advanced',
    name: 'Advanced Analytics',
    description: 'Frequency, attribution, and optimization data',
    isPremium: true,
    metrics: ['frequency_distribution', 'attribution_analysis', 'optimization_insights']
  }
];

export function ReportScheduling({ user, onNavigate, onLogout }: ReportSchedulingProps) {
  const [frequency, setFrequency] = useState('weekly');
  const [selectedFormats, setSelectedFormats] = useState(['email']);
  const [selectedMetrics, setSelectedMetrics] = useState(['performance']);
  const [deliveryTime, setDeliveryTime] = useState('09:00');
  const [recipientEmails, setRecipientEmails] = useState([user?.email || '']);
  const [newEmail, setNewEmail] = useState('');
  const [customMessage, setCustomMessage] = useState('');
  const [isActive, setIsActive] = useState(true);
  const [isPremium] = useState(false); // Mock premium status

  const handleFormatToggle = (formatId: string) => {
    setSelectedFormats(prev =>
      prev.includes(formatId)
        ? prev.filter(id => id !== formatId)
        : [...prev, formatId]
    );
  };

  const handleMetricGroupToggle = (groupId: string) => {
    const group = METRIC_GROUPS.find(g => g.id === groupId);
    if (group?.isPremium && !isPremium) {
      return; // Prevent selection of premium features
    }

    setSelectedMetrics(prev =>
      prev.includes(groupId)
        ? prev.filter(id => id !== groupId)
        : [...prev, groupId]
    );
  };

  const addRecipient = () => {
    if (newEmail && isValidEmail(newEmail) && !recipientEmails.includes(newEmail)) {
      if (recipientEmails.length >= 1 && !isPremium) {
        return; // Limit to 1 recipient for non-premium users
      }
      setRecipientEmails(prev => [...prev, newEmail]);
      setNewEmail('');
    }
  };

  const removeRecipient = (email: string) => {
    if (email === user?.email) return; // Can't remove account owner
    setRecipientEmails(prev => prev.filter(e => e !== email));
  };

  const isValidEmail = (email: string) => {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  };

  const canSave = selectedFormats.length > 0 && selectedMetrics.length > 0 && recipientEmails.length > 0;

  const handleSave = () => {
    if (canSave) {
      // Mock save - in real app, would save to backend
      onNavigate('campaign-dashboard');
    }
  };

  const handleBack = () => {
    onNavigate('campaign-dashboard');
  };

  const PremiumFeature = ({ children, feature }: { children: React.ReactNode; feature: string }) => (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <div className={`relative ${!isPremium ? 'opacity-50 cursor-not-allowed' : ''}`}>
            {children}
            {!isPremium && (
              <div className="absolute top-2 right-2">
                <Lock className="w-4 h-4 text-muted-foreground" />
              </div>
            )}
          </div>
        </TooltipTrigger>
        {!isPremium && (
          <TooltipContent>
            <p>Upgrade to Premium to access {feature}</p>
          </TooltipContent>
        )}
      </Tooltip>
    </TooltipProvider>
  );

  return (
    <AdvertiserFlowLayout
      user={user}
      currentStep="report-scheduling"
      completedSteps={['ad-creative-upload', 'targeting', 'schedule-budget', 'review-policy']}
      onNavigate={onNavigate}
      onLogout={onLogout}
      onBack={handleBack}
      showBackButton={true}
    >
      <div className="space-y-6">
        {/* Header */}
        <div className="space-y-2">
          <h1 className="text-2xl font-bold">Schedule Automated Reports</h1>
          <p className="text-muted-foreground">
            Set up automatic delivery of campaign performance reports to stay informed about your ad performance.
          </p>
        </div>

        {/* Report Status */}
        <Card className="p-6 rounded-2xl shadow-sm">
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <h3 className="font-semibold">Report Status</h3>
              <p className="text-sm text-muted-foreground">
                Enable or disable automated report delivery
              </p>
            </div>
            <div className="flex items-center space-x-3">
              <Checkbox
                checked={isActive}
                onCheckedChange={setIsActive}
              />
              <span className="text-sm font-medium">
                {isActive ? 'Active' : 'Inactive'}
              </span>
            </div>
          </div>
        </Card>

        {/* Frequency Selection */}
        <Card className="p-6 rounded-2xl shadow-sm">
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <Clock className="w-5 h-5 text-primary" />
              <h2 className="text-lg font-semibold">Delivery Frequency</h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {FREQUENCY_OPTIONS.map((option) => (
                <div key={option.id} className="relative">
                  {option.isPremium && !isPremium ? (
                    <PremiumFeature feature="custom scheduling">
                      <div
                        className={`
                          p-4 rounded-xl border-2 transition-all opacity-50 cursor-not-allowed
                          border-border
                        `}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-3">
                            <div className="w-4 h-4 rounded-full border-2 border-muted-foreground" />
                            <div>
                              <p className="font-medium">{option.name}</p>
                              <p className="text-sm text-muted-foreground">{option.description}</p>
                            </div>
                          </div>
                          <Crown className="w-4 h-4 text-muted-foreground" />
                        </div>
                      </div>
                    </PremiumFeature>
                  ) : (
                    <div
                      className={`
                        p-4 rounded-xl border-2 cursor-pointer transition-all
                        ${frequency === option.id
                          ? 'border-primary bg-primary/5'
                          : 'border-border hover:border-primary/50'
                        }
                      `}
                      onClick={() => setFrequency(option.id)}
                    >
                      <div className="flex items-center space-x-3">
                        <div
                          className={`
                            w-4 h-4 rounded-full border-2 flex items-center justify-center
                            ${frequency === option.id ? 'border-primary' : 'border-muted-foreground'}
                          `}
                        >
                          {frequency === option.id && (
                            <div className="w-2 h-2 rounded-full bg-primary" />
                          )}
                        </div>
                        <div>
                          <p className="font-medium">{option.name}</p>
                          <p className="text-sm text-muted-foreground">{option.description}</p>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>

            {/* Delivery Time */}
            <div className="space-y-2">
              <Label htmlFor="delivery-time">Delivery Time</Label>
              <div className="flex items-center gap-2">
                <Input
                  id="delivery-time"
                  type="time"
                  value={deliveryTime}
                  onChange={(e) => setDeliveryTime(e.target.value)}
                  className="w-32"
                />
                <span className="text-sm text-muted-foreground">UTC timezone</span>
              </div>
            </div>
          </div>
        </Card>

        {/* Format Selection */}
        <Card className="p-6 rounded-2xl shadow-sm">
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <FileText className="w-5 h-5 text-primary" />
              <h2 className="text-lg font-semibold">Report Format</h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {FORMAT_OPTIONS.map((format) => {
                const Icon = format.icon;
                return (
                  <div
                    key={format.id}
                    className={`
                      p-4 rounded-xl border-2 cursor-pointer transition-all
                      ${selectedFormats.includes(format.id)
                        ? 'border-primary bg-primary/5'
                        : 'border-border hover:border-primary/50'
                      }
                    `}
                    onClick={() => handleFormatToggle(format.id)}
                  >
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <Icon className="w-5 h-5 text-primary" />
                        <Checkbox 
                          checked={selectedFormats.includes(format.id)}
                          onChange={() => {}} // Handled by parent onClick
                        />
                      </div>
                      <div>
                        <p className="font-medium">{format.name}</p>
                        <p className="text-sm text-muted-foreground">{format.description}</p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </Card>

        {/* Metrics Selection */}
        <Card className="p-6 rounded-2xl shadow-sm">
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <Calendar className="w-5 h-5 text-primary" />
              <h2 className="text-lg font-semibold">Included Metrics</h2>
            </div>

            <div className="space-y-3">
              {METRIC_GROUPS.map((group) => (
                <div key={group.id} className="relative">
                  {group.isPremium && !isPremium ? (
                    <PremiumFeature feature={group.name.toLowerCase()}>
                      <div className="p-4 rounded-xl border-2 border-border opacity-50 cursor-not-allowed">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-3">
                            <Checkbox disabled />
                            <div>
                              <div className="flex items-center gap-2">
                                <p className="font-medium">{group.name}</p>
                                <Badge variant="outline" className="text-xs">
                                  <Crown className="w-3 h-3 mr-1" />
                                  Premium
                                </Badge>
                              </div>
                              <p className="text-sm text-muted-foreground">{group.description}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </PremiumFeature>
                  ) : (
                    <div
                      className={`
                        p-4 rounded-xl border-2 cursor-pointer transition-all
                        ${selectedMetrics.includes(group.id)
                          ? 'border-primary bg-primary/5'
                          : 'border-border hover:border-primary/50'
                        }
                      `}
                      onClick={() => handleMetricGroupToggle(group.id)}
                    >
                      <div className="flex items-center space-x-3">
                        <Checkbox 
                          checked={selectedMetrics.includes(group.id)}
                          onChange={() => {}} // Handled by parent onClick
                        />
                        <div>
                          <p className="font-medium">{group.name}</p>
                          <p className="text-sm text-muted-foreground">{group.description}</p>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </Card>

        {/* Recipients */}
        <Card className="p-6 rounded-2xl shadow-sm">
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <Users className="w-5 h-5 text-primary" />
              <h2 className="text-lg font-semibold">Report Recipients</h2>
            </div>

            {/* Current Recipients */}
            <div className="space-y-2">
              <Label>Current Recipients</Label>
              <div className="space-y-2">
                {recipientEmails.map((email) => (
                  <div
                    key={email}
                    className="flex items-center justify-between p-3 bg-secondary/30 rounded-xl"
                  >
                    <div className="flex items-center gap-3">
                      <Mail className="w-4 h-4 text-muted-foreground" />
                      <span className="text-sm">{email}</span>
                      {email === user?.email && (
                        <Badge variant="outline" className="text-xs">Account Owner</Badge>
                      )}
                    </div>
                    {email !== user?.email && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => removeRecipient(email)}
                      >
                        ×
                      </Button>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Add Recipient */}
            {(isPremium || recipientEmails.length < 2) && (
              <div className="space-y-2">
                <Label htmlFor="new-email">Add Recipient</Label>
                <div className="flex gap-2">
                  <Input
                    id="new-email"
                    type="email"
                    placeholder="colleague@company.com"
                    value={newEmail}
                    onChange={(e) => setNewEmail(e.target.value)}
                  />
                  <Button
                    onClick={addRecipient}
                    disabled={!newEmail || !isValidEmail(newEmail)}
                    variant="outline"
                  >
                    Add
                  </Button>
                </div>
              </div>
            )}

            {!isPremium && recipientEmails.length >= 1 && (
              <Alert className="border-primary/20 bg-primary/5">
                <Crown className="h-4 w-4 text-primary" />
                <AlertDescription>
                  Upgrade to Premium to add multiple recipients to your reports.
                </AlertDescription>
              </Alert>
            )}
          </div>
        </Card>

        {/* Custom Message */}
        <Card className="p-6 rounded-2xl shadow-sm">
          <div className="space-y-4">
            <div>
              <h3 className="font-semibold">Custom Message (Optional)</h3>
              <p className="text-sm text-muted-foreground">
                Add a personal note to include with your reports
              </p>
            </div>

            <Textarea
              placeholder="Add any context or notes for report recipients..."
              value={customMessage}
              onChange={(e) => setCustomMessage(e.target.value)}
              className="min-h-20"
              maxLength={500}
            />
            <p className="text-xs text-muted-foreground text-right">
              {customMessage.length}/500 characters
            </p>
          </div>
        </Card>

        {/* Summary */}
        <Card className="p-6 rounded-2xl shadow-sm bg-secondary/30">
          <div className="space-y-3">
            <h3 className="font-semibold flex items-center gap-2">
              <Check className="w-5 h-5 text-primary" />
              Report Summary
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
              <div>
                <p className="text-muted-foreground">Frequency</p>
                <p className="font-medium">
                  {FREQUENCY_OPTIONS.find(f => f.id === frequency)?.name} at {deliveryTime} UTC
                </p>
              </div>
              <div>
                <p className="text-muted-foreground">Format</p>
                <p className="font-medium">
                  {selectedFormats.map(f => FORMAT_OPTIONS.find(opt => opt.id === f)?.name).join(', ')}
                </p>
              </div>
              <div>
                <p className="text-muted-foreground">Recipients</p>
                <p className="font-medium">{recipientEmails.length} recipient{recipientEmails.length !== 1 ? 's' : ''}</p>
              </div>
              <div>
                <p className="text-muted-foreground">Status</p>
                <p className="font-medium">{isActive ? 'Active' : 'Inactive'}</p>
              </div>
            </div>
          </div>
        </Card>

        {/* Actions */}
        <div className="flex justify-between">
          <Button variant="outline" onClick={handleBack} className="rounded-2xl">
            Back to Dashboard
          </Button>
          <Button 
            onClick={handleSave}
            disabled={!canSave}
            className="rounded-2xl"
          >
            Save Report Schedule
          </Button>
        </div>
      </div>
    </AdvertiserFlowLayout>
  );
}