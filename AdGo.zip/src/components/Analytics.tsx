import { useState } from 'react';
import { Layout } from './Layout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Button } from './ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { 
  LineChart, 
  Line, 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import { 
  BarChart3,
  Download,
  TrendingUp,
  TrendingDown,
  Users,
  MapPin,
  Clock,
  DollarSign,
  Eye,
  MousePointer,
  Target,
  Smartphone,
  Monitor,
  Tablet
} from 'lucide-react';
import type { Screen, User } from '../App';

interface AnalyticsProps {
  user: User | null;
  onNavigate: (screen: Screen) => void;
  onLogout: () => void;
}

// Mock analytics data
const performanceData = [
  { date: '2025-01-01', impressions: 2400, clicks: 240, spend: 120, ctr: 10.0 },
  { date: '2025-01-02', impressions: 1398, clicks: 221, spend: 110, ctr: 15.8 },
  { date: '2025-01-03', impressions: 9800, clicks: 980, spend: 490, ctr: 10.0 },
  { date: '2025-01-04', impressions: 3908, clicks: 390, spend: 195, ctr: 10.0 },
  { date: '2025-01-05', impressions: 4800, clicks: 480, spend: 240, ctr: 10.0 },
  { date: '2025-01-06', impressions: 3800, clicks: 456, spend: 228, ctr: 12.0 },
  { date: '2025-01-07', impressions: 4300, clicks: 516, spend: 258, ctr: 12.0 },
];

const geoData = [
  { city: 'New York', impressions: 15420, clicks: 742, spend: 371, ctr: 4.8 },
  { city: 'Los Angeles', impressions: 12300, clicks: 467, spend: 234, ctr: 3.8 },
  { city: 'Chicago', impressions: 8900, clicks: 401, spend: 201, ctr: 4.5 },
  { city: 'Houston', impressions: 7600, clicks: 296, spend: 148, ctr: 3.9 },
  { city: 'Phoenix', impressions: 5400, clicks: 221, spend: 111, ctr: 4.1 },
  { city: 'Philadelphia', impressions: 4200, clicks: 168, spend: 84, ctr: 4.0 },
  { city: 'San Antonio', impressions: 3800, clicks: 133, spend: 67, ctr: 3.5 },
  { city: 'San Diego', impressions: 3200, clicks: 140, spend: 70, ctr: 4.4 },
];

const ageData = [
  { age: '18-24', percentage: 25, color: '#2d5016' },
  { age: '25-34', percentage: 35, color: '#4a7c2a' },
  { age: '35-44', percentage: 20, color: '#6b8e47' },
  { age: '45-54', percentage: 12, color: '#8db86b' },
  { age: '55+', percentage: 8, color: '#a8c98a' },
];

const deviceData = [
  { device: 'Mobile', impressions: 28400, percentage: 62 },
  { device: 'Desktop', impressions: 13200, percentage: 29 },
  { device: 'Tablet', impressions: 4100, percentage: 9 },
];

const hourlyData = [
  { hour: '00', impressions: 850 },
  { hour: '01', impressions: 420 },
  { hour: '02', impressions: 180 },
  { hour: '03', impressions: 120 },
  { hour: '04', impressions: 90 },
  { hour: '05', impressions: 150 },
  { hour: '06', impressions: 380 },
  { hour: '07', impressions: 720 },
  { hour: '08', impressions: 1200 },
  { hour: '09', impressions: 1800 },
  { hour: '10', impressions: 2100 },
  { hour: '11', impressions: 2400 },
  { hour: '12', impressions: 2800 },
  { hour: '13', impressions: 2600 },
  { hour: '14', impressions: 2200 },
  { hour: '15', impressions: 2500 },
  { hour: '16', impressions: 2800 },
  { hour: '17', impressions: 3200 },
  { hour: '18', impressions: 3500 },
  { hour: '19', impressions: 3800 },
  { hour: '20', impressions: 3200 },
  { hour: '21', impressions: 2800 },
  { hour: '22', impressions: 2100 },
  { hour: '23', impressions: 1400 },
];

export function Analytics({ user, onNavigate, onLogout }: AnalyticsProps) {
  const [timeRange, setTimeRange] = useState('7d');
  const [selectedMetric, setSelectedMetric] = useState('impressions');

  const totalImpressions = performanceData.reduce((sum, data) => sum + data.impressions, 0);
  const totalClicks = performanceData.reduce((sum, data) => sum + data.clicks, 0);
  const totalSpend = performanceData.reduce((sum, data) => sum + data.spend, 0);
  const avgCTR = totalImpressions > 0 ? (totalClicks / totalImpressions) * 100 : 0;
  const avgCPM = totalImpressions > 0 ? (totalSpend / totalImpressions) * 1000 : 0;
  const avgCPC = totalClicks > 0 ? totalSpend / totalClicks : 0;

  return (
    <Layout user={user} currentScreen="analytics" onNavigate={onNavigate} onLogout={onLogout}>
      {/* Header */}
      <div className="border-b border-border bg-background px-6 py-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">Analytics & Insights</h1>
            <p className="text-muted-foreground">Deep dive into your campaign performance</p>
          </div>
          
          <div className="flex items-center space-x-2">
            <Select value={timeRange} onValueChange={setTimeRange}>
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="7d">Last 7 days</SelectItem>
                <SelectItem value="30d">Last 30 days</SelectItem>
                <SelectItem value="90d">Last 90 days</SelectItem>
                <SelectItem value="1y">Last year</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline" size="sm">
              <Download className="size-4 mr-2" />
              Export
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-auto p-6 space-y-6">
        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Impressions</CardTitle>
              <Eye className="size-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{(totalImpressions / 1000).toFixed(1)}K</div>
              <div className="flex items-center text-xs text-muted-foreground">
                <TrendingUp className="size-3 mr-1 text-green-500" />
                +12.5% vs previous period
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Click-Through Rate</CardTitle>
              <MousePointer className="size-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{avgCTR.toFixed(1)}%</div>
              <div className="flex items-center text-xs text-muted-foreground">
                <TrendingDown className="size-3 mr-1 text-red-500" />
                -0.3% vs previous period
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Cost Per Click</CardTitle>
              <DollarSign className="size-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">${avgCPC.toFixed(2)}</div>
              <div className="flex items-center text-xs text-muted-foreground">
                <TrendingUp className="size-3 mr-1 text-green-500" />
                +5.2% vs previous period
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Cost Per Mille</CardTitle>
              <BarChart3 className="size-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">${avgCPM.toFixed(2)}</div>
              <div className="flex items-center text-xs text-muted-foreground">
                <TrendingDown className="size-3 mr-1 text-red-500" />
                -2.1% vs previous period
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="performance" className="space-y-6">
          <TabsList>
            <TabsTrigger value="performance">Performance</TabsTrigger>
            <TabsTrigger value="audience">Audience</TabsTrigger>
            <TabsTrigger value="geography">Geography</TabsTrigger>
            <TabsTrigger value="timing">Timing</TabsTrigger>
          </TabsList>

          {/* Performance Tab */}
          <TabsContent value="performance" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Campaign Performance Over Time</CardTitle>
                    <CardDescription>Track your key metrics across time</CardDescription>
                  </div>
                  <Select value={selectedMetric} onValueChange={setSelectedMetric}>
                    <SelectTrigger className="w-40">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="impressions">Impressions</SelectItem>
                      <SelectItem value="clicks">Clicks</SelectItem>
                      <SelectItem value="spend">Spend</SelectItem>
                      <SelectItem value="ctr">CTR</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={400}>
                  <LineChart data={performanceData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip />
                    <Line 
                      type="monotone" 
                      dataKey={selectedMetric} 
                      stroke="#2d5016" 
                      strokeWidth={2}
                      dot={{ fill: '#2d5016' }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Performance Breakdown</CardTitle>
                  <CardDescription>Detailed metrics analysis</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm">Impressions</span>
                      <span className="text-sm font-medium">{totalImpressions.toLocaleString()}</span>
                    </div>
                    <Progress value={100} className="h-2" />
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm">Clicks</span>
                      <span className="text-sm font-medium">{totalClicks.toLocaleString()}</span>
                    </div>
                    <Progress value={(totalClicks / totalImpressions) * 100 * 10} className="h-2" />
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm">Conversions</span>
                      <span className="text-sm font-medium">127</span>
                    </div>
                    <Progress value={25} className="h-2" />
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm">Revenue</span>
                      <span className="text-sm font-medium">$3,240</span>
                    </div>
                    <Progress value={65} className="h-2" />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Device Breakdown</CardTitle>
                  <CardDescription>Performance by device type</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {deviceData.map((device) => (
                    <div key={device.device} className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        {device.device === 'Mobile' && <Smartphone className="size-4 text-primary" />}
                        {device.device === 'Desktop' && <Monitor className="size-4 text-primary" />}
                        {device.device === 'Tablet' && <Tablet className="size-4 text-primary" />}
                        <span className="text-sm font-medium">{device.device}</span>
                      </div>
                      <div className="flex items-center space-x-3">
                        <div className="flex-1 w-20">
                          <Progress value={device.percentage} className="h-2" />
                        </div>
                        <span className="text-sm text-muted-foreground w-12 text-right">
                          {device.percentage}%
                        </span>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Audience Tab */}
          <TabsContent value="audience" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Age Distribution</CardTitle>
                  <CardDescription>Audience breakdown by age groups</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                      <Pie
                        data={ageData}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={120}
                        paddingAngle={5}
                        dataKey="percentage"
                      >
                        {ageData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                  <div className="mt-4 space-y-2">
                    {ageData.map((item) => (
                      <div key={item.age} className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <div 
                            className="size-3 rounded-full" 
                            style={{ backgroundColor: item.color }}
                          />
                          <span className="text-sm">{item.age}</span>
                        </div>
                        <span className="text-sm font-medium">{item.percentage}%</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Audience Insights</CardTitle>
                  <CardDescription>Key demographics and interests</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h4 className="font-medium mb-2">Top Interests</h4>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm">Technology</span>
                        <Badge variant="secondary">34%</Badge>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm">Fashion</span>
                        <Badge variant="secondary">28%</Badge>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm">Travel</span>
                        <Badge variant="secondary">22%</Badge>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm">Sports</span>
                        <Badge variant="secondary">16%</Badge>
                      </div>
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="font-medium mb-2">Gender Split</h4>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Female</span>
                        <div className="flex items-center space-x-2">
                          <Progress value={58} className="w-20 h-2" />
                          <span className="text-sm text-muted-foreground">58%</span>
                        </div>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Male</span>
                        <div className="flex items-center space-x-2">
                          <Progress value={42} className="w-20 h-2" />
                          <span className="text-sm text-muted-foreground">42%</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="font-medium mb-2">New vs Returning</h4>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm">New Users</span>
                        <div className="flex items-center space-x-2">
                          <Progress value={72} className="w-20 h-2" />
                          <span className="text-sm text-muted-foreground">72%</span>
                        </div>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Returning</span>
                        <div className="flex items-center space-x-2">
                          <Progress value={28} className="w-20 h-2" />
                          <span className="text-sm text-muted-foreground">28%</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Geography Tab */}
          <TabsContent value="geography" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <MapPin className="size-5 mr-2" />
                  Geographic Performance
                </CardTitle>
                <CardDescription>Performance metrics by city and region</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={400}>
                  <BarChart data={geoData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="city" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="impressions" fill="#2d5016" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>City Performance Details</CardTitle>
                <CardDescription>Detailed breakdown by location</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {geoData.map((city, index) => (
                    <div key={city.city} className="flex items-center justify-between p-3 border border-border rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className="size-8 bg-primary/10 rounded-full flex items-center justify-center">
                          <span className="text-sm font-medium">{index + 1}</span>
                        </div>
                        <div>
                          <p className="font-medium">{city.city}</p>
                          <p className="text-sm text-muted-foreground">
                            {city.impressions.toLocaleString()} impressions
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-4 text-sm">
                        <div className="text-center">
                          <p className="font-medium">{city.clicks}</p>
                          <p className="text-muted-foreground">Clicks</p>
                        </div>
                        <div className="text-center">
                          <p className="font-medium">{city.ctr}%</p>
                          <p className="text-muted-foreground">CTR</p>
                        </div>
                        <div className="text-center">
                          <p className="font-medium">${city.spend}</p>
                          <p className="text-muted-foreground">Spend</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Timing Tab */}
          <TabsContent value="timing" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Clock className="size-5 mr-2" />
                  Hourly Performance
                </CardTitle>
                <CardDescription>When your audience is most active</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <AreaChart data={hourlyData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="hour" />
                    <YAxis />
                    <Tooltip />
                    <Area 
                      type="monotone" 
                      dataKey="impressions" 
                      stroke="#2d5016" 
                      fill="#2d5016" 
                      fillOpacity={0.6}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Peak Hours</CardTitle>
                  <CardDescription>Best performing time slots</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex justify-between items-center p-3 bg-primary/5 rounded-lg">
                    <div>
                      <p className="font-medium">7:00 PM - 8:00 PM</p>
                      <p className="text-sm text-muted-foreground">Peak engagement time</p>
                    </div>
                    <Badge variant="default">Best</Badge>
                  </div>
                  
                  <div className="flex justify-between items-center p-3 bg-secondary rounded-lg">
                    <div>
                      <p className="font-medium">12:00 PM - 1:00 PM</p>
                      <p className="text-sm text-muted-foreground">Lunch hour spike</p>
                    </div>
                    <Badge variant="secondary">Good</Badge>
                  </div>
                  
                  <div className="flex justify-between items-center p-3 bg-secondary rounded-lg">
                    <div>
                      <p className="font-medium">9:00 AM - 10:00 AM</p>
                      <p className="text-sm text-muted-foreground">Morning commute</p>
                    </div>
                    <Badge variant="secondary">Good</Badge>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Optimization Tips</CardTitle>
                  <CardDescription>Improve your campaign timing</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-start space-x-3">
                    <Target className="size-5 text-primary mt-0.5" />
                    <div>
                      <p className="text-sm font-medium">Schedule more ads during 7-8 PM</p>
                      <p className="text-xs text-muted-foreground">38% higher CTR during this hour</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-3">
                    <TrendingUp className="size-5 text-primary mt-0.5" />
                    <div>
                      <p className="text-sm font-medium">Reduce overnight spend</p>
                      <p className="text-xs text-muted-foreground">2-6 AM shows poor performance</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-3">
                    <Users className="size-5 text-primary mt-0.5" />
                    <div>
                      <p className="text-sm font-medium">Weekend performance differs</p>
                      <p className="text-xs text-muted-foreground">Consider separate weekend campaigns</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
}