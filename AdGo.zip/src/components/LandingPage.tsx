import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';
import { Target, BarChart3, MapPin, Zap, TrendingUp, Users } from 'lucide-react';
import type { Screen } from '../App';

interface LandingPageProps {
  onNavigate: (screen: Screen) => void;
}

export function LandingPage({ onNavigate }: LandingPageProps) {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border/50 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="size-8 bg-primary rounded-lg flex items-center justify-center">
              <Target className="size-5 text-primary-foreground" />
            </div>
            <span className="text-xl font-semibold text-primary">AdGo</span>
          </div>
          
          <div className="flex items-center space-x-4">
            <Button variant="ghost" onClick={() => onNavigate('auth')}>
              Sign In
            </Button>
            <Button onClick={() => onNavigate('auth')}>
              Get Started
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto text-center max-w-4xl">
          <Badge variant="secondary" className="mb-6">
            <Zap className="size-3 mr-1" />
            Now in Beta
          </Badge>
          
          <h1 className="text-5xl lg:text-6xl font-bold mb-6 bg-gradient-to-br from-primary via-accent to-primary bg-clip-text text-transparent">
            Hyper-Targeted Advertising Made Simple
          </h1>
          
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Reach your ideal customers with precision targeting, real-time analytics, and geo-location insights. 
            AdGo makes advertising smarter, not harder.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" onClick={() => onNavigate('auth')} className="text-lg px-8">
              Start Free Trial
            </Button>
            <Button variant="outline" size="lg" className="text-lg px-8">
              Join Waitlist
            </Button>
          </div>
          
          <p className="text-sm text-muted-foreground mt-4">
            No credit card required • 14-day free trial
          </p>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-secondary/50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Everything you need to scale your ads</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Our platform combines advanced targeting with intuitive design to help you reach the right audience at the right time.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="size-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                  <Target className="size-6 text-primary" />
                </div>
                <h3 className="text-lg font-semibold mb-2">Precision Targeting</h3>
                <p className="text-muted-foreground">
                  Target by demographics, interests, location, and behavior to reach your ideal customers.
                </p>
              </CardContent>
            </Card>
            
            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="size-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                  <BarChart3 className="size-6 text-primary" />
                </div>
                <h3 className="text-lg font-semibold mb-2">Real-time Analytics</h3>
                <p className="text-muted-foreground">
                  Track performance with detailed metrics, conversion tracking, and ROI insights.
                </p>
              </CardContent>
            </Card>
            
            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="size-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                  <MapPin className="size-6 text-primary" />
                </div>
                <h3 className="text-lg font-semibold mb-2">Geo-targeting</h3>
                <p className="text-muted-foreground">
                  Reach customers in specific cities, regions, or custom radius areas with heat map insights.
                </p>
              </CardContent>
            </Card>
            
            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="size-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                  <TrendingUp className="size-6 text-primary" />
                </div>
                <h3 className="text-lg font-semibold mb-2">Campaign Optimization</h3>
                <p className="text-muted-foreground">
                  AI-powered suggestions to improve performance and maximize your advertising budget.
                </p>
              </CardContent>
            </Card>
            
            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="size-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                  <Users className="size-6 text-primary" />
                </div>
                <h3 className="text-lg font-semibold mb-2">Team Collaboration</h3>
                <p className="text-muted-foreground">
                  Invite team members, assign roles, and collaborate on campaigns seamlessly.
                </p>
              </CardContent>
            </Card>
            
            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="size-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                  <Zap className="size-6 text-primary" />
                </div>
                <h3 className="text-lg font-semibold mb-2">Quick Setup</h3>
                <p className="text-muted-foreground">
                  Launch your first campaign in minutes with our intuitive drag-and-drop interface.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto text-center max-w-3xl">
          <h2 className="text-4xl font-bold mb-6">Ready to supercharge your advertising?</h2>
          <p className="text-xl text-muted-foreground mb-8">
            Join thousands of businesses already growing with AdGo's hyper-targeted advertising platform.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" onClick={() => onNavigate('auth')} className="text-lg px-8">
              Start Your Free Trial
            </Button>
            <Button variant="outline" size="lg" className="text-lg px-8">
              Schedule Demo
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border/50 py-8 px-4">
        <div className="container mx-auto">
          <div className="flex flex-col md:flex-row items-center justify-between">
            <div className="flex items-center space-x-2 mb-4 md:mb-0">
              <div className="size-6 bg-primary rounded flex items-center justify-center">
                <Target className="size-4 text-primary-foreground" />
              </div>
              <span className="font-semibold text-primary">AdGo</span>
            </div>
            
            <p className="text-sm text-muted-foreground">
              © 2025 AdGo. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}