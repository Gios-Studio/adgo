import { useState } from 'react';
import { MapPin, Lock, Users, Globe, Crown } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Label } from './ui/label';
import { Checkbox } from './ui/checkbox';
import { RadioGroup, RadioGroupItem } from './ui/radio-group';
import { Slider } from './ui/slider';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Badge } from './ui/badge';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from './ui/tooltip';
import { AdvertiserFlowLayout } from './AdvertiserFlowLayout';
import { Screen, User } from '../App';

interface TargetingProps {
  user: User | null;
  onNavigate: (screen: Screen) => void;
  onLogout: () => void;
}

const CITIES = [
  { id: 'nairobi', name: 'Nairobi', country: 'Kenya', population: '4.4M' },
  { id: 'accra', name: 'Accra', country: 'Ghana', population: '2.3M' },
  { id: 'cape-town', name: 'Cape Town', country: 'South Africa', population: '4.6M' },
  { id: 'kigali', name: 'Kigali', country: 'Rwanda', population: '1.2M' },
  { id: 'abuja', name: 'Abuja', country: 'Nigeria', population: '3.8M' },
];

const MUNICIPALITIES = {
  nairobi: ['Westlands', 'Karen', 'Kilimani', 'Lavington', 'Parklands'],
  accra: ['East Legon', 'Cantonments', 'Airport Residential', 'Labone', 'North Ridge'],
  'cape-town': ['City Bowl', 'Waterfront', 'Green Point', 'Sea Point', 'Camps Bay'],
  kigali: ['Nyarugenge', 'Gasabo', 'Kicukiro', 'Kimisagara', 'Gikondo'],
  abuja: ['Maitama', 'Asokoro', 'Wuse', 'Garki', 'Central Area'],
};

const LANGUAGES = [
  { id: 'en', name: 'English', isPremium: false },
  { id: 'sw', name: 'Swahili', isPremium: true },
  { id: 'fr', name: 'French', isPremium: true },
  { id: 'ar', name: 'Arabic', isPremium: true },
  { id: 'zu', name: 'Zulu', isPremium: true },
  { id: 'yo', name: 'Yoruba', isPremium: true },
];

export function Targeting({ user, onNavigate, onLogout }: TargetingProps) {
  const [selectedCities, setSelectedCities] = useState<string[]>([]);
  const [selectedMunicipalities, setSelectedMunicipalities] = useState<string[]>([]);
  const [radiusTargeting, setRadiusTargeting] = useState(false);
  const [ageRange, setAgeRange] = useState([18, 65]);
  const [gender, setGender] = useState('all');
  const [selectedLanguages, setSelectedLanguages] = useState(['en']);
  const [isPremium] = useState(false); // Mock premium status

  const handleCityToggle = (cityId: string) => {
    setSelectedCities(prev => 
      prev.includes(cityId) 
        ? prev.filter(id => id !== cityId)
        : [...prev, cityId]
    );
    // Reset municipalities when city selection changes
    setSelectedMunicipalities([]);
  };

  const handleMunicipalityToggle = (municipality: string) => {
    setSelectedMunicipalities(prev =>
      prev.includes(municipality)
        ? prev.filter(m => m !== municipality)
        : [...prev, municipality]
    );
  };

  const handleLanguageToggle = (langId: string) => {
    const language = LANGUAGES.find(l => l.id === langId);
    if (language?.isPremium && !isPremium) {
      return; // Prevent selection of premium languages for non-premium users
    }

    setSelectedLanguages(prev =>
      prev.includes(langId)
        ? prev.filter(id => id !== langId)
        : [...prev, langId]
    );
  };

  const canProceed = selectedCities.length > 0;

  const handleNext = () => {
    if (canProceed) {
      onNavigate('schedule-budget');
    }
  };

  const handleBack = () => {
    onNavigate('ad-creative-upload');
  };

  const PremiumFeature = ({ children, feature }: { children: React.ReactNode; feature: string }) => (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <div className={`relative ${!isPremium ? 'opacity-50 cursor-not-allowed' : ''}`}>
            {children}
            {!isPremium && (
              <div className="absolute top-2 right-2">
                <Lock className="w-4 h-4 text-muted-foreground" />
              </div>
            )}
          </div>
        </TooltipTrigger>
        {!isPremium && (
          <TooltipContent>
            <p>Upgrade to Premium to access {feature}</p>
          </TooltipContent>
        )}
      </Tooltip>
    </TooltipProvider>
  );

  return (
    <AdvertiserFlowLayout
      user={user}
      currentStep="targeting"
      completedSteps={['ad-creative-upload']}
      onNavigate={onNavigate}
      onLogout={onLogout}
      onBack={handleBack}
    >
      <div className="space-y-6">
        {/* Location Targeting */}
        <Card className="p-6 rounded-2xl shadow-sm">
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <MapPin className="w-5 h-5 text-primary" />
              <h2 className="text-lg font-semibold">Location Targeting</h2>
            </div>

            <div className="space-y-4">
              <div>
                <Label className="text-base font-medium">Select Cities *</Label>
                <p className="text-sm text-muted-foreground mb-3">
                  Choose which cities to target for your campaign
                </p>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {CITIES.map((city) => (
                    <div
                      key={city.id}
                      className={`
                        p-4 rounded-xl border-2 cursor-pointer transition-all
                        ${selectedCities.includes(city.id) 
                          ? 'border-primary bg-primary/5' 
                          : 'border-border hover:border-primary/50'
                        }
                      `}
                      onClick={() => handleCityToggle(city.id)}
                    >
                      <div className="flex items-center space-x-3">
                        <Checkbox 
                          checked={selectedCities.includes(city.id)}
                          onChange={() => {}} // Handled by parent onClick
                        />
                        <div className="flex-1">
                          <p className="font-medium">{city.name}</p>
                          <p className="text-sm text-muted-foreground">
                            {city.country} • {city.population}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Municipalities - Premium Feature */}
              {selectedCities.length > 0 && (
                <PremiumFeature feature="municipality targeting">
                  <div className="space-y-3">
                    <div className="flex items-center gap-2">
                      <Label className="text-base font-medium">Municipalities</Label>
                      <Badge variant="outline" className="text-xs">
                        <Crown className="w-3 h-3 mr-1" />
                        Premium
                      </Badge>
                    </div>
                    
                    {selectedCities.map(cityId => {
                      const municipalities = MUNICIPALITIES[cityId as keyof typeof MUNICIPALITIES] || [];
                      const cityName = CITIES.find(c => c.id === cityId)?.name;
                      
                      return (
                        <div key={cityId} className="space-y-2">
                          <p className="text-sm font-medium text-muted-foreground">{cityName}</p>
                          <div className="flex flex-wrap gap-2">
                            {municipalities.map(municipality => (
                              <button
                                key={municipality}
                                disabled={!isPremium}
                                onClick={() => handleMunicipalityToggle(municipality)}
                                className={`
                                  px-3 py-1 rounded-full text-sm transition-colors
                                  ${selectedMunicipalities.includes(municipality)
                                    ? 'bg-primary text-primary-foreground'
                                    : 'bg-secondary text-secondary-foreground hover:bg-primary/10'
                                  }
                                  ${!isPremium ? 'cursor-not-allowed opacity-50' : 'cursor-pointer'}
                                `}
                              >
                                {municipality}
                              </button>
                            ))}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </PremiumFeature>
              )}

              {/* Radius Targeting - Premium Feature */}
              <PremiumFeature feature="radius targeting">
                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <Label className="text-base font-medium">Radius Targeting</Label>
                    <Badge variant="outline" className="text-xs">
                      <Crown className="w-3 h-3 mr-1" />
                      Premium
                    </Badge>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Checkbox 
                      checked={radiusTargeting}
                      onCheckedChange={setRadiusTargeting}
                      disabled={!isPremium}
                    />
                    <span className="text-sm">Target users within a specific radius of a location</span>
                  </div>
                </div>
              </PremiumFeature>
            </div>
          </div>
        </Card>

        {/* Demographics */}
        <Card className="p-6 rounded-2xl shadow-sm">
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <Users className="w-5 h-5 text-primary" />
              <h2 className="text-lg font-semibold">Demographics</h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Age Range */}
              <div className="space-y-3">
                <Label className="text-base font-medium">Age Range</Label>
                <div className="px-3">
                  <Slider
                    value={ageRange}
                    onValueChange={setAgeRange}
                    max={65}
                    min={18}
                    step={1}
                    className="w-full"
                  />
                  <div className="flex justify-between text-sm text-muted-foreground mt-2">
                    <span>{ageRange[0]} years</span>
                    <span>{ageRange[1]} years</span>
                  </div>
                </div>
              </div>

              {/* Gender */}
              <div className="space-y-3">
                <Label className="text-base font-medium">Gender</Label>
                <RadioGroup value={gender} onValueChange={setGender}>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="all" id="all" />
                    <Label htmlFor="all">All</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="male" id="male" />
                    <Label htmlFor="male">Male</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="female" id="female" />
                    <Label htmlFor="female">Female</Label>
                  </div>
                </RadioGroup>
              </div>
            </div>
          </div>
        </Card>

        {/* Language Targeting */}
        <Card className="p-6 rounded-2xl shadow-sm">
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <Globe className="w-5 h-5 text-primary" />
              <h2 className="text-lg font-semibold">Language Targeting</h2>
            </div>

            <div className="space-y-3">
              <Label className="text-base font-medium">Select Languages</Label>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {LANGUAGES.map((language) => (
                  <div
                    key={language.id}
                    className={`
                      relative p-3 rounded-xl border-2 cursor-pointer transition-all
                      ${selectedLanguages.includes(language.id)
                        ? 'border-primary bg-primary/5'
                        : 'border-border hover:border-primary/50'
                      }
                      ${language.isPremium && !isPremium ? 'opacity-50 cursor-not-allowed' : ''}
                    `}
                    onClick={() => handleLanguageToggle(language.id)}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <Checkbox 
                          checked={selectedLanguages.includes(language.id)}
                          onChange={() => {}} // Handled by parent onClick
                          disabled={language.isPremium && !isPremium}
                        />
                        <span className="text-sm font-medium">{language.name}</span>
                      </div>
                      {language.isPremium && (
                        <Crown className="w-3 h-3 text-muted-foreground" />
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </Card>

        {/* Audience Estimate */}
        <Card className="p-6 rounded-2xl shadow-sm bg-secondary/30">
          <div className="space-y-3">
            <h3 className="font-semibold">Estimated Audience</h3>
            <div className="flex items-center gap-4">
              <div className="text-2xl font-bold text-primary">
                {(selectedCities.length * 150000).toLocaleString()}
              </div>
              <div className="text-sm text-muted-foreground">
                potential users across {selectedCities.length} {selectedCities.length === 1 ? 'city' : 'cities'}
              </div>
            </div>
            <p className="text-xs text-muted-foreground">
              Estimate based on active users aged {ageRange[0]}-{ageRange[1]} in selected locations
            </p>
          </div>
        </Card>

        {/* Navigation */}
        <div className="flex justify-between">
          <Button variant="outline" onClick={handleBack} className="rounded-2xl">
            Back
          </Button>
          <Button 
            onClick={handleNext}
            disabled={!canProceed}
            className="rounded-2xl"
          >
            Continue to Schedule
          </Button>
        </div>
      </div>
    </AdvertiserFlowLayout>
  );
}