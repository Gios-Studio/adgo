import { useState } from 'react';
import { CheckCircle, Eye, Users, DollarSign, Calendar, MapPin, Globe, Target, AlertTriangle, Rocket, Save } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Checkbox } from './ui/checkbox';
import { Badge } from './ui/badge';
import { Alert, AlertDescription } from './ui/alert';
import { AdvertiserFlowLayout } from './AdvertiserFlowLayout';
import { Screen, User } from '../App';

interface ReviewPolicyProps {
  user: User | null;
  onNavigate: (screen: Screen) => void;
  onLogout: () => void;
}

// Mock campaign data - in a real app, this would come from state management
const MOCK_CAMPAIGN_DATA = {
  creative: {
    type: 'image',
    fileName: 'brand-campaign.jpg',
    size: '2.4MB',
    landingUrl: 'https://example.com/landing',
    ctaText: 'Learn More'
  },
  targeting: {
    cities: ['Nairobi', 'Accra', 'Cape Town'],
    ageRange: [25, 45],
    gender: 'all',
    languages: ['English'],
    estimatedReach: 450000
  },
  schedule: {
    startDate: '2024-02-01',
    endDate: '2024-02-15',
    daypart: 'commute',
    duration: 14
  },
  budget: {
    type: 'total',
    amount: 500,
    objective: 'awareness',
    estimatedImpressions: 200000,
    estimatedCPM: 2.50
  }
};

export function ReviewPolicy({ user, onNavigate, onLogout }: ReviewPolicyProps) {
  const [policyAccepted, setPolicyAccepted] = useState(false);
  const [termsAccepted, setTermsAccepted] = useState(false);
  const [isLaunching, setIsLaunching] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  const canLaunch = policyAccepted && termsAccepted;

  const handleBack = () => {
    onNavigate('schedule-budget');
  };

  const handleSaveDraft = async () => {
    setIsSaving(true);
    // Mock API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    setIsSaving(false);
    // In a real app, you'd save to backend and show success message
    onNavigate('campaign-dashboard');
  };

  const handleLaunch = async () => {
    if (!canLaunch) return;
    
    setIsLaunching(true);
    // Mock API call
    await new Promise(resolve => setTimeout(resolve, 2000));
    setIsLaunching(false);
    
    // Navigate to campaign dashboard
    onNavigate('campaign-dashboard');
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  return (
    <AdvertiserFlowLayout
      user={user}
      currentStep="review-policy"
      completedSteps={['ad-creative-upload', 'targeting', 'schedule-budget']}
      onNavigate={onNavigate}
      onLogout={onLogout}
      onBack={handleBack}
    >
      <div className="space-y-6">
        {/* Campaign Summary */}
        <Card className="p-6 rounded-2xl shadow-sm">
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <Eye className="w-5 h-5 text-primary" />
              <h2 className="text-lg font-semibold">Campaign Summary</h2>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Creative */}
              <div className="space-y-3">
                <h3 className="font-medium flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-primary" />
                  Creative
                </h3>
                <div className="bg-secondary/30 rounded-xl p-4">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <Badge variant="outline">{MOCK_CAMPAIGN_DATA.creative.type}</Badge>
                      <span className="text-sm font-medium">{MOCK_CAMPAIGN_DATA.creative.fileName}</span>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      Size: {MOCK_CAMPAIGN_DATA.creative.size}
                    </p>
                    <p className="text-sm">
                      <span className="font-medium">Landing URL:</span> {MOCK_CAMPAIGN_DATA.creative.landingUrl}
                    </p>
                    <p className="text-sm">
                      <span className="font-medium">CTA:</span> "{MOCK_CAMPAIGN_DATA.creative.ctaText}"
                    </p>
                  </div>
                </div>
              </div>

              {/* Targeting */}
              <div className="space-y-3">
                <h3 className="font-medium flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-primary" />
                  Targeting
                </h3>
                <div className="bg-secondary/30 rounded-xl p-4">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <MapPin className="w-4 h-4 text-muted-foreground" />
                      <span className="text-sm">
                        {MOCK_CAMPAIGN_DATA.targeting.cities.join(', ')}
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Users className="w-4 h-4 text-muted-foreground" />
                      <span className="text-sm">
                        Ages {MOCK_CAMPAIGN_DATA.targeting.ageRange[0]}-{MOCK_CAMPAIGN_DATA.targeting.ageRange[1]}, 
                        {MOCK_CAMPAIGN_DATA.targeting.gender === 'all' ? ' All genders' : ` ${MOCK_CAMPAIGN_DATA.targeting.gender}`}
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Globe className="w-4 h-4 text-muted-foreground" />
                      <span className="text-sm">
                        {MOCK_CAMPAIGN_DATA.targeting.languages.join(', ')}
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Target className="w-4 h-4 text-muted-foreground" />
                      <span className="text-sm">
                        Est. reach: {MOCK_CAMPAIGN_DATA.targeting.estimatedReach.toLocaleString()} users
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Schedule */}
              <div className="space-y-3">
                <h3 className="font-medium flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-primary" />
                  Schedule
                </h3>
                <div className="bg-secondary/30 rounded-xl p-4">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4 text-muted-foreground" />
                      <span className="text-sm">
                        {formatDate(MOCK_CAMPAIGN_DATA.schedule.startDate)} - {formatDate(MOCK_CAMPAIGN_DATA.schedule.endDate)}
                      </span>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      Duration: {MOCK_CAMPAIGN_DATA.schedule.duration} days
                    </p>
                    <p className="text-sm text-muted-foreground">
                      Timing: {MOCK_CAMPAIGN_DATA.schedule.daypart === 'commute' ? 'Commute Hours (7-9 AM, 5-7 PM)' : 'All Day'}
                    </p>
                  </div>
                </div>
              </div>

              {/* Budget */}
              <div className="space-y-3">
                <h3 className="font-medium flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-primary" />
                  Budget & Objective
                </h3>
                <div className="bg-secondary/30 rounded-xl p-4">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <DollarSign className="w-4 h-4 text-muted-foreground" />
                      <span className="text-sm">
                        ${MOCK_CAMPAIGN_DATA.budget.amount} {MOCK_CAMPAIGN_DATA.budget.type} budget
                      </span>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      Objective: {MOCK_CAMPAIGN_DATA.budget.objective === 'awareness' ? 'Brand Awareness (CPM)' : 'Drive Traffic (CPC)'}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      Est. impressions: {MOCK_CAMPAIGN_DATA.budget.estimatedImpressions.toLocaleString()}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      Est. CPM: ${MOCK_CAMPAIGN_DATA.budget.estimatedCPM}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </Card>

        {/* Performance Estimates */}
        <Card className="p-6 rounded-2xl shadow-sm bg-gradient-to-r from-primary/5 to-accent/5">
          <div className="space-y-4">
            <h3 className="font-semibold">Performance Estimates</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-primary">
                  {MOCK_CAMPAIGN_DATA.targeting.estimatedReach.toLocaleString()}
                </div>
                <div className="text-sm text-muted-foreground">Estimated Reach</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-primary">
                  {MOCK_CAMPAIGN_DATA.budget.estimatedImpressions.toLocaleString()}
                </div>
                <div className="text-sm text-muted-foreground">Impressions</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-primary">2.8%</div>
                <div className="text-sm text-muted-foreground">Expected CTR</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-primary">5,600</div>
                <div className="text-sm text-muted-foreground">Est. Clicks</div>
              </div>
            </div>
          </div>
        </Card>

        {/* Policy & Compliance */}
        <Card className="p-6 rounded-2xl shadow-sm">
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-primary" />
              <h2 className="text-lg font-semibold">Policy & Compliance</h2>
            </div>

            <Alert className="border-primary/20 bg-primary/5">
              <AlertTriangle className="h-4 w-4 text-primary" />
              <AlertDescription>
                Your campaign will be reviewed for compliance before going live. This typically takes 1-2 hours during business hours.
              </AlertDescription>
            </Alert>

            <div className="space-y-4">
              <div className="flex items-start space-x-3">
                <Checkbox
                  checked={policyAccepted}
                  onCheckedChange={setPolicyAccepted}
                  className="mt-1"
                />
                <div className="space-y-1">
                  <Label className="text-base font-medium leading-5">
                    I confirm that my ad content complies with AdGo's Advertising Policies
                  </Label>
                  <p className="text-sm text-muted-foreground">
                    This includes ensuring content is appropriate, doesn't violate copyright, and meets quality standards.{' '}
                    <a href="#" className="text-primary hover:underline">View full policy</a>
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-3">
                <Checkbox
                  checked={termsAccepted}
                  onCheckedChange={setTermsAccepted}
                  className="mt-1"
                />
                <div className="space-y-1">
                  <Label className="text-base font-medium leading-5">
                    I agree to the Terms of Service and Privacy Policy
                  </Label>
                  <p className="text-sm text-muted-foreground">
                    By launching this campaign, you agree to our terms and billing policies.{' '}
                    <a href="#" className="text-primary hover:underline">Read terms</a>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </Card>

        {/* Launch Actions */}
        <div className="flex flex-col sm:flex-row gap-4 justify-between">
          <Button variant="outline" onClick={handleBack} className="rounded-2xl">
            Back to Budget
          </Button>
          
          <div className="flex gap-3">
            <Button 
              variant="outline" 
              onClick={handleSaveDraft}
              disabled={isSaving}
              className="rounded-2xl"
            >
              {isSaving ? (
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
                  Saving...
                </div>
              ) : (
                <>
                  <Save className="w-4 h-4 mr-2" />
                  Save as Draft
                </>
              )}
            </Button>
            
            <Button 
              onClick={handleLaunch}
              disabled={!canLaunch || isLaunching}
              className="rounded-2xl min-w-32"
            >
              {isLaunching ? (
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
                  Launching...
                </div>
              ) : (
                <>
                  <Rocket className="w-4 h-4 mr-2" />
                  Launch Campaign
                </>
              )}
            </Button>
          </div>
        </div>

        {!canLaunch && (
          <Alert className="border-destructive/20 bg-destructive/5">
            <AlertTriangle className="h-4 w-4 text-destructive" />
            <AlertDescription className="text-destructive">
              Please accept both the advertising policy and terms of service to launch your campaign.
            </AlertDescription>
          </Alert>
        )}
      </div>
    </AdvertiserFlowLayout>
  );
}