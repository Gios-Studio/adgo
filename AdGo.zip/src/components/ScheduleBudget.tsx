import { useState } from 'react';
import { Calendar, Clock, DollarSign, Target, Lock, Crown } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Label } from './ui/label';
import { Input } from './ui/input';
import { RadioGroup, RadioGroupItem } from './ui/radio-group';
import { Checkbox } from './ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Badge } from './ui/badge';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from './ui/tooltip';
import { AdvertiserFlowLayout } from './AdvertiserFlowLayout';
import { Screen, User } from '../App';

interface ScheduleBudgetProps {
  user: User | null;
  onNavigate: (screen: Screen) => void;
  onLogout: () => void;
}

const DAYPART_OPTIONS = [
  { id: 'all-day', name: 'All Day', description: '24/7', isPremium: false },
  { id: 'commute', name: 'Commute Hours', description: '7-9 AM, 5-7 PM', isPremium: false },
  { id: 'evenings', name: 'Evenings', description: '6-11 PM', isPremium: false },
  { id: 'custom', name: 'Custom Hours', description: 'Set specific times', isPremium: true },
];

const FREQUENCY_OPTIONS = [
  { value: '1', label: '1 time per day' },
  { value: '3', label: '3 times per day (recommended)' },
  { value: '5', label: '5 times per day' },
  { value: '10', label: '10 times per day' },
];

export function ScheduleBudget({ user, onNavigate, onLogout }: ScheduleBudgetProps) {
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [selectedDaypart, setSelectedDaypart] = useState('all-day');
  const [budgetType, setBudgetType] = useState<'total' | 'daily'>('total');
  const [budgetAmount, setBudgetAmount] = useState('');
  const [objective, setObjective] = useState<'awareness' | 'traffic'>('awareness');
  const [frequencyCap, setFrequencyCap] = useState('3');
  const [frequencyEnabled, setFrequencyEnabled] = useState(true);
  const [isPremium] = useState(false); // Mock premium status

  const getTomorrowDate = () => {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    return tomorrow.toISOString().split('T')[0];
  };

  const getMinEndDate = () => {
    if (!startDate) return getTomorrowDate();
    const start = new Date(startDate);
    start.setDate(start.getDate() + 1);
    return start.toISOString().split('T')[0];
  };

  const canProceed = startDate && endDate && budgetAmount && parseFloat(budgetAmount) > 0;

  const handleNext = () => {
    if (canProceed) {
      onNavigate('review-policy');
    }
  };

  const handleBack = () => {
    onNavigate('targeting');
  };

  const calculateEstimatedReach = () => {
    const budget = parseFloat(budgetAmount) || 0;
    const cpmRate = objective === 'awareness' ? 2.5 : 3.5; // Mock CPM rates
    const cpcRate = objective === 'traffic' ? 0.8 : 1.2; // Mock CPC rates
    
    if (objective === 'awareness') {
      return Math.floor((budget / cpmRate) * 1000);
    } else {
      return Math.floor(budget / cpcRate);
    }
  };

  const PremiumFeature = ({ children, feature }: { children: React.ReactNode; feature: string }) => (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <div className={`relative ${!isPremium ? 'opacity-50 cursor-not-allowed' : ''}`}>
            {children}
            {!isPremium && (
              <div className="absolute top-2 right-2">
                <Lock className="w-4 h-4 text-muted-foreground" />
              </div>
            )}
          </div>
        </TooltipTrigger>
        {!isPremium && (
          <TooltipContent>
            <p>Upgrade to Premium to access {feature}</p>
          </TooltipContent>
        )}
      </Tooltip>
    </TooltipProvider>
  );

  return (
    <AdvertiserFlowLayout
      user={user}
      currentStep="schedule-budget"
      completedSteps={['ad-creative-upload', 'targeting']}
      onNavigate={onNavigate}
      onLogout={onLogout}
      onBack={handleBack}
    >
      <div className="space-y-6">
        {/* Schedule */}
        <Card className="p-6 rounded-2xl shadow-sm">
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <Calendar className="w-5 h-5 text-primary" />
              <h2 className="text-lg font-semibold">Campaign Schedule</h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="start-date">Start Date *</Label>
                <Input
                  id="start-date"
                  type="date"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  min={getTomorrowDate()}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="end-date">End Date *</Label>
                <Input
                  id="end-date"
                  type="date"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                  min={getMinEndDate()}
                />
              </div>
            </div>

            {/* Dayparting */}
            <div className="space-y-3">
              <Label className="text-base font-medium">When to show ads</Label>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {DAYPART_OPTIONS.map((option) => (
                  <div key={option.id} className="relative">
                    <div
                      className={`
                        p-4 rounded-xl border-2 cursor-pointer transition-all
                        ${selectedDaypart === option.id
                          ? 'border-primary bg-primary/5'
                          : 'border-border hover:border-primary/50'
                        }
                        ${option.isPremium && !isPremium ? 'opacity-50 cursor-not-allowed' : ''}
                      `}
                      onClick={() => {
                        if (!option.isPremium || isPremium) {
                          setSelectedDaypart(option.id);
                        }
                      }}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <div
                            className={`
                              w-4 h-4 rounded-full border-2 flex items-center justify-center
                              ${selectedDaypart === option.id ? 'border-primary' : 'border-muted-foreground'}
                            `}
                          >
                            {selectedDaypart === option.id && (
                              <div className="w-2 h-2 rounded-full bg-primary" />
                            )}
                          </div>
                          <div>
                            <p className="font-medium">{option.name}</p>
                            <p className="text-sm text-muted-foreground">{option.description}</p>
                          </div>
                        </div>
                        {option.isPremium && (
                          <Crown className="w-4 h-4 text-muted-foreground" />
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </Card>

        {/* Budget */}
        <Card className="p-6 rounded-2xl shadow-sm">
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <DollarSign className="w-5 h-5 text-primary" />
              <h2 className="text-lg font-semibold">Budget</h2>
            </div>

            <div className="space-y-4">
              {/* Budget Type */}
              <div className="space-y-3">
                <Label className="text-base font-medium">Budget Type</Label>
                <RadioGroup value={budgetType} onValueChange={(value: 'total' | 'daily') => setBudgetType(value)}>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="total" id="total" />
                    <Label htmlFor="total">Total Campaign Budget</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="daily" id="daily" />
                    <Label htmlFor="daily">Daily Budget</Label>
                  </div>
                </RadioGroup>
              </div>

              {/* Budget Amount */}
              <div className="space-y-2">
                <Label htmlFor="budget-amount">
                  {budgetType === 'total' ? 'Total Budget' : 'Daily Budget'} (USD) *
                </Label>
                <div className="relative">
                  <div className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground">
                    $
                  </div>
                  <Input
                    id="budget-amount"
                    type="number"
                    placeholder="0.00"
                    value={budgetAmount}
                    onChange={(e) => setBudgetAmount(e.target.value)}
                    className="pl-8"
                    min="1"
                    step="0.01"
                  />
                </div>
                <p className="text-xs text-muted-foreground">
                  Minimum: $1.00 {budgetType === 'daily' ? 'per day' : 'total'}
                </p>
              </div>
            </div>
          </div>
        </Card>

        {/* Campaign Objective */}
        <Card className="p-6 rounded-2xl shadow-sm">
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <Target className="w-5 h-5 text-primary" />
              <h2 className="text-lg font-semibold">Campaign Objective</h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div
                className={`
                  p-4 rounded-xl border-2 cursor-pointer transition-all
                  ${objective === 'awareness'
                    ? 'border-primary bg-primary/5'
                    : 'border-border hover:border-primary/50'
                  }
                `}
                onClick={() => setObjective('awareness')}
              >
                <div className="space-y-2">
                  <div className="flex items-center space-x-3">
                    <div
                      className={`
                        w-4 h-4 rounded-full border-2 flex items-center justify-center
                        ${objective === 'awareness' ? 'border-primary' : 'border-muted-foreground'}
                      `}
                    >
                      {objective === 'awareness' && (
                        <div className="w-2 h-2 rounded-full bg-primary" />
                      )}
                    </div>
                    <p className="font-medium">Brand Awareness</p>
                  </div>
                  <p className="text-sm text-muted-foreground pl-7">
                    Optimize for impressions (CPM pricing)
                  </p>
                  <p className="text-xs text-muted-foreground pl-7">
                    Best for: Building brand recognition
                  </p>
                </div>
              </div>

              <div
                className={`
                  p-4 rounded-xl border-2 cursor-pointer transition-all
                  ${objective === 'traffic'
                    ? 'border-primary bg-primary/5'
                    : 'border-border hover:border-primary/50'
                  }
                `}
                onClick={() => setObjective('traffic')}
              >
                <div className="space-y-2">
                  <div className="flex items-center space-x-3">
                    <div
                      className={`
                        w-4 h-4 rounded-full border-2 flex items-center justify-center
                        ${objective === 'traffic' ? 'border-primary' : 'border-muted-foreground'}
                      `}
                    >
                      {objective === 'traffic' && (
                        <div className="w-2 h-2 rounded-full bg-primary" />
                      )}
                    </div>
                    <p className="font-medium">Drive Traffic</p>
                  </div>
                  <p className="text-sm text-muted-foreground pl-7">
                    Optimize for clicks (CPC pricing)
                  </p>
                  <p className="text-xs text-muted-foreground pl-7">
                    Best for: Driving website visits
                  </p>
                </div>
              </div>
            </div>
          </div>
        </Card>

        {/* Frequency Capping */}
        <Card className="p-6 rounded-2xl shadow-sm">
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <Clock className="w-5 h-5 text-primary" />
              <h2 className="text-lg font-semibold">Frequency Control</h2>
            </div>

            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                <Checkbox
                  checked={frequencyEnabled}
                  onCheckedChange={setFrequencyEnabled}
                />
                <div>
                  <Label className="text-base font-medium">Enable frequency capping</Label>
                  <p className="text-sm text-muted-foreground">
                    Limit how often the same user sees your ad
                  </p>
                </div>
              </div>

              {frequencyEnabled && (
                <div className="space-y-2 ml-8">
                  <Label htmlFor="frequency-cap">Maximum frequency</Label>
                  <Select value={frequencyCap} onValueChange={setFrequencyCap}>
                    <SelectTrigger className="w-full md:w-64">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {FREQUENCY_OPTIONS.map((option) => (
                        <SelectItem key={option.value} value={option.value}>
                          {option.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}
            </div>
          </div>
        </Card>

        {/* Budget Estimate */}
        {budgetAmount && parseFloat(budgetAmount) > 0 && (
          <Card className="p-6 rounded-2xl shadow-sm bg-secondary/30">
            <div className="space-y-3">
              <h3 className="font-semibold">Campaign Estimates</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div>
                  <p className="text-sm text-muted-foreground">Estimated Reach</p>
                  <p className="text-lg font-semibold">
                    {calculateEstimatedReach().toLocaleString()}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">
                    {objective === 'awareness' ? 'Impressions' : 'Clicks'}
                  </p>
                  <p className="text-lg font-semibold">
                    {objective === 'awareness' ? 
                      Math.floor(calculateEstimatedReach() * 1.5).toLocaleString() : 
                      calculateEstimatedReach().toLocaleString()
                    }
                  </p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">
                    {objective === 'awareness' ? 'CPM' : 'CPC'}
                  </p>
                  <p className="text-lg font-semibold">
                    ${objective === 'awareness' ? '2.50' : '0.80'}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Duration</p>
                  <p className="text-lg font-semibold">
                    {startDate && endDate ? 
                      Math.ceil((new Date(endDate).getTime() - new Date(startDate).getTime()) / (1000 * 60 * 60 * 24)) : 
                      0
                    } days
                  </p>
                </div>
              </div>
            </div>
          </Card>
        )}

        {/* Navigation */}
        <div className="flex justify-between">
          <Button variant="outline" onClick={handleBack} className="rounded-2xl">
            Back
          </Button>
          <Button 
            onClick={handleNext}
            disabled={!canProceed}
            className="rounded-2xl"
          >
            Review Campaign
          </Button>
        </div>
      </div>
    </AdvertiserFlowLayout>
  );
}