import { useState } from 'react';
import { Layout } from './Layout';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Progress } from './ui/progress';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from './ui/table';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from './ui/dropdown-menu';
import { 
  Search,
  Filter,
  Plus,
  MoreHorizontal,
  Play,
  Pause,
  Copy,
  Edit,
  Trash2,
  Eye,
  Calendar,
  DollarSign,
  MousePointer,
  TrendingUp,
  TrendingDown
} from 'lucide-react';
import type { Screen, User } from '../App';

interface CampaignManagementProps {
  user: User | null;
  onNavigate: (screen: Screen) => void;
  onLogout: () => void;
}

interface Campaign {
  id: string;
  name: string;
  status: 'active' | 'paused' | 'scheduled' | 'completed' | 'pending';
  impressions: number;
  clicks: number;
  ctr: number;
  spent: number;
  budget: number;
  startDate: string;
  endDate?: string;
  targetCity: string;
  createdAt: string;
}

// Mock campaign data
const mockCampaigns: Campaign[] = [
  {
    id: '1',
    name: 'Summer Sale Campaign',
    status: 'active',
    impressions: 15420,
    clicks: 741,
    ctr: 4.8,
    spent: 324,
    budget: 500,
    startDate: '2025-01-15',
    endDate: '2025-01-30',
    targetCity: 'New York',
    createdAt: '2025-01-10'
  },
  {
    id: '2',
    name: 'Holiday Special',
    status: 'scheduled',
    impressions: 0,
    clicks: 0,
    ctr: 0,
    spent: 0,
    budget: 300,
    startDate: '2025-01-25',
    endDate: '2025-02-15',
    targetCity: 'Los Angeles',
    createdAt: '2025-01-12'
  },
  {
    id: '3',
    name: 'Back to School',
    status: 'paused',
    impressions: 8950,
    clicks: 290,
    ctr: 3.2,
    spent: 145,
    budget: 400,
    startDate: '2025-01-01',
    targetCity: 'Chicago',
    createdAt: '2025-01-01'
  },
  {
    id: '4',
    name: 'Black Friday Deals',
    status: 'completed',
    impressions: 45200,
    clicks: 2260,
    ctr: 5.0,
    spent: 850,
    budget: 850,
    startDate: '2024-11-20',
    endDate: '2024-11-30',
    targetCity: 'Houston',
    createdAt: '2024-11-15'
  },
  {
    id: '5',
    name: 'New Product Launch',
    status: 'pending',
    impressions: 0,
    clicks: 0,
    ctr: 0,
    spent: 0,
    budget: 600,
    startDate: '2025-02-01',
    targetCity: 'Phoenix',
    createdAt: '2025-01-20'
  }
];

export function CampaignManagement({ user, onNavigate, onLogout }: CampaignManagementProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedTab, setSelectedTab] = useState('all');
  const [campaigns] = useState<Campaign[]>(mockCampaigns);

  const getStatusColor = (status: Campaign['status']) => {
    switch (status) {
      case 'active': return 'bg-green-500';
      case 'paused': return 'bg-yellow-500';
      case 'scheduled': return 'bg-blue-500';
      case 'completed': return 'bg-gray-500';
      case 'pending': return 'bg-orange-500';
      default: return 'bg-gray-500';
    }
  };

  const getStatusVariant = (status: Campaign['status']) => {
    switch (status) {
      case 'active': return 'default';
      case 'paused': return 'secondary';
      case 'scheduled': return 'outline';
      case 'completed': return 'secondary';
      case 'pending': return 'outline';
      default: return 'secondary';
    }
  };

  const filteredCampaigns = campaigns.filter(campaign => {
    const matchesSearch = campaign.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         campaign.targetCity.toLowerCase().includes(searchTerm.toLowerCase());
    
    if (selectedTab === 'all') return matchesSearch;
    return matchesSearch && campaign.status === selectedTab;
  });

  const totalStats = campaigns.reduce((acc, campaign) => ({
    impressions: acc.impressions + campaign.impressions,
    clicks: acc.clicks + campaign.clicks,
    spent: acc.spent + campaign.spent,
    budget: acc.budget + campaign.budget
  }), { impressions: 0, clicks: 0, spent: 0, budget: 0 });

  const avgCTR = totalStats.impressions > 0 ? (totalStats.clicks / totalStats.impressions) * 100 : 0;

  const handleCampaignAction = (campaignId: string, action: string) => {
    console.log(`${action} campaign ${campaignId}`);
    // Handle campaign actions
  };

  return (
    <Layout user={user} currentScreen="campaigns" onNavigate={onNavigate} onLogout={onLogout}>
      {/* Header */}
      <div className="border-b border-border bg-background px-6 py-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">My Campaigns</h1>
            <p className="text-muted-foreground">Manage and monitor your advertising campaigns</p>
          </div>
          
          <Button onClick={() => onNavigate('ad-upload')}>
            <Plus className="size-4 mr-2" />
            Create Campaign
          </Button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-auto p-6 space-y-6">
        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Campaigns</CardTitle>
              <Eye className="size-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{campaigns.length}</div>
              <div className="flex items-center text-xs text-muted-foreground">
                <TrendingUp className="size-3 mr-1 text-green-500" />
                +2 this month
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Impressions</CardTitle>
              <Eye className="size-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{(totalStats.impressions / 1000).toFixed(1)}K</div>
              <div className="flex items-center text-xs text-muted-foreground">
                <TrendingUp className="size-3 mr-1 text-green-500" />
                +15.2% vs last month
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Avg CTR</CardTitle>
              <MousePointer className="size-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{avgCTR.toFixed(1)}%</div>
              <div className="flex items-center text-xs text-muted-foreground">
                <TrendingDown className="size-3 mr-1 text-red-500" />
                -0.3% vs last month
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Spend</CardTitle>
              <DollarSign className="size-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">${totalStats.spent.toLocaleString()}</div>
              <div className="flex items-center text-xs text-muted-foreground">
                <TrendingUp className="size-3 mr-1 text-green-500" />
                +8.7% vs last month
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters and Search */}
        <Card>
          <CardHeader>
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div>
                <CardTitle>Campaign Overview</CardTitle>
                <CardDescription>Track performance of all your campaigns</CardDescription>
              </div>
              
              <div className="flex items-center space-x-2">
                <div className="relative">
                  <Search className="size-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
                  <Input
                    placeholder="Search campaigns..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10 w-64"
                  />
                </div>
                <Button variant="outline" size="sm">
                  <Filter className="size-4 mr-2" />
                  Filter
                </Button>
              </div>
            </div>
          </CardHeader>
          
          <CardContent>
            <Tabs value={selectedTab} onValueChange={setSelectedTab}>
              <TabsList className="mb-4">
                <TabsTrigger value="all">All ({campaigns.length})</TabsTrigger>
                <TabsTrigger value="active">Active ({campaigns.filter(c => c.status === 'active').length})</TabsTrigger>
                <TabsTrigger value="paused">Paused ({campaigns.filter(c => c.status === 'paused').length})</TabsTrigger>
                <TabsTrigger value="scheduled">Scheduled ({campaigns.filter(c => c.status === 'scheduled').length})</TabsTrigger>
                <TabsTrigger value="completed">Completed ({campaigns.filter(c => c.status === 'completed').length})</TabsTrigger>
              </TabsList>
              
              <TabsContent value={selectedTab}>
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Campaign</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Impressions</TableHead>
                        <TableHead>Clicks</TableHead>
                        <TableHead>CTR</TableHead>
                        <TableHead>Spend</TableHead>
                        <TableHead>Budget</TableHead>
                        <TableHead>Location</TableHead>
                        <TableHead className="w-[50px]">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredCampaigns.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={9} className="text-center py-8">
                            <div className="text-muted-foreground">
                              {searchTerm ? 'No campaigns found matching your search.' : 'No campaigns found.'}
                            </div>
                          </TableCell>
                        </TableRow>
                      ) : (
                        filteredCampaigns.map((campaign) => (
                          <TableRow key={campaign.id}>
                            <TableCell>
                              <div className="space-y-1">
                                <p className="font-medium">{campaign.name}</p>
                                <div className="flex items-center text-xs text-muted-foreground">
                                  <Calendar className="size-3 mr-1" />
                                  {new Date(campaign.startDate).toLocaleDateString()}
                                  {campaign.endDate && ` - ${new Date(campaign.endDate).toLocaleDateString()}`}
                                </div>
                              </div>
                            </TableCell>
                            <TableCell>
                              <Badge variant={getStatusVariant(campaign.status)} className="capitalize">
                                <div className={`size-2 rounded-full mr-2 ${getStatusColor(campaign.status)}`} />
                                {campaign.status}
                              </Badge>
                            </TableCell>
                            <TableCell>{campaign.impressions.toLocaleString()}</TableCell>
                            <TableCell>{campaign.clicks.toLocaleString()}</TableCell>
                            <TableCell>{campaign.ctr.toFixed(1)}%</TableCell>
                            <TableCell>${campaign.spent.toLocaleString()}</TableCell>
                            <TableCell>
                              <div className="space-y-1">
                                <div className="flex items-center justify-between text-sm">
                                  <span>${campaign.spent}</span>
                                  <span className="text-muted-foreground">/ ${campaign.budget}</span>
                                </div>
                                <Progress 
                                  value={(campaign.spent / campaign.budget) * 100} 
                                  className="h-1"
                                />
                              </div>
                            </TableCell>
                            <TableCell>{campaign.targetCity}</TableCell>
                            <TableCell>
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="ghost" size="sm">
                                    <MoreHorizontal className="size-4" />
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                  <DropdownMenuItem onClick={() => handleCampaignAction(campaign.id, 'view')}>
                                    <Eye className="size-4 mr-2" />
                                    View Details
                                  </DropdownMenuItem>
                                  <DropdownMenuItem onClick={() => handleCampaignAction(campaign.id, 'edit')}>
                                    <Edit className="size-4 mr-2" />
                                    Edit
                                  </DropdownMenuItem>
                                  <DropdownMenuItem onClick={() => handleCampaignAction(campaign.id, 'duplicate')}>
                                    <Copy className="size-4 mr-2" />
                                    Duplicate
                                  </DropdownMenuItem>
                                  <DropdownMenuSeparator />
                                  {campaign.status === 'active' ? (
                                    <DropdownMenuItem onClick={() => handleCampaignAction(campaign.id, 'pause')}>
                                      <Pause className="size-4 mr-2" />
                                      Pause
                                    </DropdownMenuItem>
                                  ) : campaign.status === 'paused' ? (
                                    <DropdownMenuItem onClick={() => handleCampaignAction(campaign.id, 'resume')}>
                                      <Play className="size-4 mr-2" />
                                      Resume
                                    </DropdownMenuItem>
                                  ) : null}
                                  <DropdownMenuSeparator />
                                  <DropdownMenuItem 
                                    onClick={() => handleCampaignAction(campaign.id, 'delete')}
                                    className="text-destructive"
                                  >
                                    <Trash2 className="size-4 mr-2" />
                                    Delete
                                  </DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        {/* Recent Activity */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Activity</CardTitle>
            <CardDescription>Latest updates on your campaigns</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-start space-x-3 p-3 rounded-lg bg-muted/50">
                <div className="size-2 rounded-full bg-green-500 mt-2" />
                <div className="space-y-1">
                  <p className="text-sm font-medium">Summer Sale Campaign reached 15K impressions</p>
                  <p className="text-xs text-muted-foreground">2 hours ago</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-3 p-3 rounded-lg bg-muted/50">
                <div className="size-2 rounded-full bg-blue-500 mt-2" />
                <div className="space-y-1">
                  <p className="text-sm font-medium">Holiday Special campaign scheduled for tomorrow</p>
                  <p className="text-xs text-muted-foreground">1 day ago</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-3 p-3 rounded-lg bg-muted/50">
                <div className="size-2 rounded-full bg-yellow-500 mt-2" />
                <div className="space-y-1">
                  <p className="text-sm font-medium">Back to School campaign paused due to budget limit</p>
                  <p className="text-xs text-muted-foreground">3 days ago</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}