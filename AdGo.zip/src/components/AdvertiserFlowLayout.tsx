import { ArrowLeft, LogOut } from 'lucide-react';
import { Button } from './ui/button';
import { StepperProgress } from './StepperProgress';
import { Screen, User } from '../App';

interface AdvertiserFlowLayoutProps {
  user: User | null;
  currentStep: string;
  completedSteps: string[];
  onNavigate: (screen: Screen) => void;
  onLogout: () => void;
  children: React.ReactNode;
  onBack?: () => void;
  showBackButton?: boolean;
}

const FLOW_STEPS = [
  { id: 'ad-creative-upload', title: 'Creative', description: 'Upload ad content' },
  { id: 'targeting', title: 'Targeting', description: 'Define audience' },
  { id: 'schedule-budget', title: 'Schedule', description: 'Set timing & budget' },
  { id: 'review-policy', title: 'Review', description: 'Finalize & launch' },
];

export function AdvertiserFlowLayout({ 
  user, 
  currentStep, 
  completedSteps, 
  onNavigate, 
  onLogout, 
  children, 
  onBack,
  showBackButton = true 
}: AdvertiserFlowLayoutProps) {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b border-border bg-white">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            {showBackButton && onBack && (
              <Button variant="ghost" size="sm" onClick={onBack}>
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back
              </Button>
            )}
            <div>
              <h1 className="text-xl font-semibold text-foreground">Create Campaign</h1>
              <p className="text-sm text-muted-foreground">
                Set up your hyper-targeted ad campaign
              </p>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="text-sm text-muted-foreground">
              {user?.name} • {user?.company}
            </div>
            <Button variant="ghost" size="sm" onClick={onLogout}>
              <LogOut className="w-4 h-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </div>

      {/* Stepper Progress */}
      <StepperProgress 
        steps={FLOW_STEPS}
        currentStep={currentStep}
        completedSteps={completedSteps}
      />

      {/* Main Content */}
      <div className="max-w-4xl mx-auto px-6 py-8">
        {children}
      </div>
    </div>
  );
}