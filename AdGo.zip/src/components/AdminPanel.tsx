import { useState } from 'react';
import { Layout } from './Layout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Input } from './ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from './ui/table';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from './ui/dropdown-menu';
import { 
  LineChart, 
  Line, 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  BarChart,
  Bar
} from 'recharts';
import { 
  Shield,
  Users,
  FileText,
  DollarSign,
  TrendingUp,
  TrendingDown,
  Eye,
  Search,
  Filter,
  MoreHorizontal,
  Check,
  X,
  Pause,
  Play,
  AlertTriangle,
  CheckCircle,
  Clock
} from 'lucide-react';
import type { Screen, User } from '../App';

interface AdminPanelProps {
  user: User | null;
  onNavigate: (screen: Screen) => void;
  onLogout: () => void;
}

interface PendingAd {
  id: string;
  name: string;
  advertiser: string;
  category: string;
  submittedAt: string;
  status: 'pending' | 'approved' | 'rejected';
  targetCity: string;
  budget: number;
}

interface SystemUser {
  id: string;
  name: string;
  email: string;
  company: string;
  role: 'advertiser' | 'admin';
  status: 'active' | 'suspended' | 'pending';
  joinedAt: string;
  totalSpend: number;
  campaigns: number;
}

// Mock data
const systemStatsData = [
  { date: '2025-01-01', users: 1250, revenue: 12400, ads: 450 },
  { date: '2025-01-02', users: 1280, revenue: 13200, ads: 480 },
  { date: '2025-01-03', users: 1320, revenue: 14100, ads: 520 },
  { date: '2025-01-04', users: 1350, revenue: 14800, ads: 540 },
  { date: '2025-01-05', users: 1390, revenue: 15600, ads: 580 },
  { date: '2025-01-06', users: 1420, revenue: 16200, ads: 600 },
  { date: '2025-01-07', users: 1450, revenue: 16900, ads: 620 },
];

const mockPendingAds: PendingAd[] = [
  {
    id: '1',
    name: 'Summer Fashion Collection',
    advertiser: 'Fashion Forward Inc.',
    category: 'Fashion',
    submittedAt: '2025-01-24T10:30:00Z',
    status: 'pending',
    targetCity: 'New York',
    budget: 500
  },
  {
    id: '2',
    name: 'Tech Gadget Launch',
    advertiser: 'TechCorp',
    category: 'Technology',
    submittedAt: '2025-01-24T09:15:00Z',
    status: 'pending',
    targetCity: 'San Francisco',
    budget: 1000
  },
  {
    id: '3',
    name: 'Restaurant Grand Opening',
    advertiser: 'Bistro Delicious',
    category: 'Food & Drink',
    submittedAt: '2025-01-24T08:45:00Z',
    status: 'pending',
    targetCity: 'Chicago',
    budget: 300
  }
];

const mockUsers: SystemUser[] = [
  {
    id: '1',
    name: 'John Smith',
    email: 'john@fashionforward.com',
    company: 'Fashion Forward Inc.',
    role: 'advertiser',
    status: 'active',
    joinedAt: '2024-11-15',
    totalSpend: 2450,
    campaigns: 8
  },
  {
    id: '2',
    name: 'Sarah Johnson',
    email: 'sarah@techcorp.com',
    company: 'TechCorp',
    role: 'advertiser',
    status: 'active',
    joinedAt: '2024-12-01',
    totalSpend: 5600,
    campaigns: 12
  },
  {
    id: '3', 
    name: 'Mike Wilson',
    email: 'mike@bistrodelicious.com',
    company: 'Bistro Delicious',
    role: 'advertiser',
    status: 'pending',
    joinedAt: '2025-01-20',
    totalSpend: 0,
    campaigns: 0
  }
];

export function AdminPanel({ user, onNavigate, onLogout }: AdminPanelProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedTab, setSelectedTab] = useState('overview');
  const [pendingAds] = useState<PendingAd[]>(mockPendingAds);
  const [users] = useState<SystemUser[]>(mockUsers);

  const totalUsers = 1450;
  const totalRevenue = 16900;
  const totalAds = 620;
  const pendingAdCount = pendingAds.filter(ad => ad.status === 'pending').length;

  const handleAdAction = (adId: string, action: 'approve' | 'reject') => {
    console.log(`${action} ad ${adId}`);
    // Handle ad approval/rejection
  };

  const handleUserAction = (userId: string, action: string) => {
    console.log(`${action} user ${userId}`);
    // Handle user actions
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'outline';
      case 'approved': return 'default';
      case 'rejected': return 'destructive';
      case 'active': return 'default';
      case 'suspended': return 'destructive';
      default: return 'secondary';
    }
  };

  const filteredUsers = users.filter(user => 
    user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.company.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <Layout user={user} currentScreen="admin" onNavigate={onNavigate} onLogout={onLogout}>
      {/* Header */}
      <div className="border-b border-border bg-background px-6 py-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold flex items-center">
              <Shield className="size-6 mr-2 text-primary" />
              Admin Panel
            </h1>
            <p className="text-muted-foreground">System administration and content moderation</p>
          </div>
          
          <div className="flex items-center space-x-2">
            <Badge variant="outline" className="text-orange-500 border-orange-500">
              {pendingAdCount} Pending Reviews
            </Badge>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-auto p-6">
        <Tabs value={selectedTab} onValueChange={setSelectedTab} className="space-y-6">
          <TabsList>
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="ads">Ad Reviews</TabsTrigger>
            <TabsTrigger value="users">User Management</TabsTrigger>
            <TabsTrigger value="analytics">System Analytics</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            {/* System Stats */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Users</CardTitle>
                  <Users className="size-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{totalUsers.toLocaleString()}</div>
                  <div className="flex items-center text-xs text-muted-foreground">
                    <TrendingUp className="size-3 mr-1 text-green-500" />
                    +12.3% from last month
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
                  <DollarSign className="size-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">${totalRevenue.toLocaleString()}</div>
                  <div className="flex items-center text-xs text-muted-foreground">
                    <TrendingUp className="size-3 mr-1 text-green-500" />
                    +18.7% from last month
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Active Ads</CardTitle>
                  <FileText className="size-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{totalAds}</div>
                  <div className="flex items-center text-xs text-muted-foreground">
                    <TrendingUp className="size-3 mr-1 text-green-500" />
                    +8.4% from last month
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Pending Reviews</CardTitle>
                  <AlertTriangle className="size-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{pendingAdCount}</div>
                  <div className="flex items-center text-xs text-muted-foreground">
                    <Clock className="size-3 mr-1 text-orange-500" />
                    Requires attention
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* System Growth Chart */}
            <Card>
              <CardHeader>
                <CardTitle>Platform Growth</CardTitle>
                <CardDescription>Key metrics over the last 7 days</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <AreaChart data={systemStatsData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip />
                    <Area type="monotone" dataKey="users" stackId="1" stroke="#2d5016" fill="#2d5016" fillOpacity={0.6} />
                    <Area type="monotone" dataKey="ads" stackId="2" stroke="#4a7c2a" fill="#4a7c2a" fillOpacity={0.6} />
                  </AreaChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Recent Activity */}
            <Card>
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
                <CardDescription>Latest system events and user actions</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-start space-x-3">
                    <CheckCircle className="size-5 text-green-500 mt-0.5" />
                    <div className="space-y-1">
                      <p className="text-sm font-medium">Ad approved: "Tech Gadget Launch"</p>
                      <p className="text-xs text-muted-foreground">Approved by Admin • 2 hours ago</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-3">
                    <Users className="size-5 text-blue-500 mt-0.5" />
                    <div className="space-y-1">
                      <p className="text-sm font-medium">New user registered: Sarah Johnson</p>
                      <p className="text-xs text-muted-foreground">TechCorp • 4 hours ago</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-3">
                    <AlertTriangle className="size-5 text-orange-500 mt-0.5" />
                    <div className="space-y-1">
                      <p className="text-sm font-medium">Ad flagged for review: "Restaurant Grand Opening"</p>
                      <p className="text-xs text-muted-foreground">Automatic content filter • 6 hours ago</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Ad Reviews Tab */}
          <TabsContent value="ads" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Pending Ad Reviews</CardTitle>
                    <CardDescription>Ads waiting for approval or rejection</CardDescription>
                  </div>
                  <Badge variant="outline">
                    {pendingAdCount} pending
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {pendingAds.map((ad) => (
                    <div key={ad.id} className="flex items-center justify-between p-4 border border-border rounded-lg">
                      <div className="space-y-1">
                        <div className="flex items-center space-x-2">
                          <p className="font-medium">{ad.name}</p>
                          <Badge variant="outline">{ad.category}</Badge>
                        </div>
                        <p className="text-sm text-muted-foreground">
                          by {ad.advertiser} • {ad.targetCity} • ${ad.budget} budget
                        </p>
                        <p className="text-xs text-muted-foreground">
                          Submitted {new Date(ad.submittedAt).toLocaleString()}
                        </p>
                      </div>
                      
                      <div className="flex items-center space-x-2">
                        <Button
                          size="sm"
                          onClick={() => handleAdAction(ad.id, 'approve')}
                          className="bg-green-600 text-white hover:bg-green-700"
                        >
                          <Check className="size-4 mr-1" />
                          Approve
                        </Button>
                        <Button
                          variant="destructive"
                          size="sm"
                          onClick={() => handleAdAction(ad.id, 'reject')}
                        >
                          <X className="size-4 mr-1" />
                          Reject
                        </Button>
                        <Button variant="outline" size="sm">
                          <Eye className="size-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* User Management Tab */}
          <TabsContent value="users" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                  <div>
                    <CardTitle>User Management</CardTitle>
                    <CardDescription>Manage platform users and their permissions</CardDescription>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <div className="relative">
                      <Search className="size-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
                      <Input
                        placeholder="Search users..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="pl-10 w-64"
                      />
                    </div>
                    <Button variant="outline" size="sm">
                      <Filter className="size-4 mr-2" />
                      Filter
                    </Button>
                  </div>
                </div>
              </CardHeader>
              
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>User</TableHead>
                      <TableHead>Company</TableHead>
                      <TableHead>Role</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Campaigns</TableHead>
                      <TableHead>Total Spend</TableHead>
                      <TableHead>Joined</TableHead>
                      <TableHead className="w-[50px]">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredUsers.map((user) => (
                      <TableRow key={user.id}>
                        <TableCell>
                          <div>
                            <p className="font-medium">{user.name}</p>
                            <p className="text-sm text-muted-foreground">{user.email}</p>
                          </div>
                        </TableCell>
                        <TableCell>{user.company}</TableCell>
                        <TableCell>
                          <Badge variant="outline">{user.role}</Badge>
                        </TableCell>
                        <TableCell>
                          <Badge variant={getStatusColor(user.status)}>{user.status}</Badge>
                        </TableCell>
                        <TableCell>{user.campaigns}</TableCell>
                        <TableCell>${user.totalSpend.toLocaleString()}</TableCell>
                        <TableCell>{new Date(user.joinedAt).toLocaleDateString()}</TableCell>
                        <TableCell>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="sm">
                                <MoreHorizontal className="size-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem onClick={() => handleUserAction(user.id, 'view')}>
                                <Eye className="size-4 mr-2" />
                                View Profile
                              </DropdownMenuItem>
                              {user.status === 'active' ? (
                                <DropdownMenuItem onClick={() => handleUserAction(user.id, 'suspend')}>
                                  <Pause className="size-4 mr-2" />
                                  Suspend User
                                </DropdownMenuItem>
                              ) : (
                                <DropdownMenuItem onClick={() => handleUserAction(user.id, 'activate')}>
                                  <Play className="size-4 mr-2" />
                                  Activate User
                                </DropdownMenuItem>
                              )}
                              <DropdownMenuSeparator />
                              <DropdownMenuItem 
                                onClick={() => handleUserAction(user.id, 'delete')}
                                className="text-destructive"
                              >
                                <X className="size-4 mr-2" />
                                Delete User
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* System Analytics Tab */}
          <TabsContent value="analytics" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Revenue Growth</CardTitle>
                  <CardDescription>Platform revenue over time</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={250}>
                    <LineChart data={systemStatsData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" />
                      <YAxis />
                      <Tooltip />
                      <Line type="monotone" dataKey="revenue" stroke="#2d5016" strokeWidth={2} />
                    </LineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>User Growth</CardTitle>
                  <CardDescription>New user registrations</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={250}>
                    <BarChart data={systemStatsData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="users" fill="#4a7c2a" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>System Health</CardTitle>
                <CardDescription>Platform performance metrics</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-green-500">99.9%</div>
                    <p className="text-sm text-muted-foreground">Uptime</p>
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-blue-500">2.3s</div>
                    <p className="text-sm text-muted-foreground">Avg Response Time</p>
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-primary">45K</div>
                    <p className="text-sm text-muted-foreground">API Requests/hr</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
}