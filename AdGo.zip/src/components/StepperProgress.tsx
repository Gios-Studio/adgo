import { Check } from 'lucide-react';

interface Step {
  id: string;
  title: string;
  description?: string;
}

interface StepperProgressProps {
  steps: Step[];
  currentStep: string;
  completedSteps: string[];
}

export function StepperProgress({ steps, currentStep, completedSteps }: StepperProgressProps) {
  const currentIndex = steps.findIndex(step => step.id === currentStep);

  return (
    <div className="w-full bg-white border-b border-border p-6">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between">
          {steps.map((step, index) => {
            const isCompleted = completedSteps.includes(step.id);
            const isCurrent = step.id === currentStep;
            const isLast = index === steps.length - 1;

            return (
              <div key={step.id} className="flex items-center flex-1">
                <div className="flex flex-col items-center">
                  {/* Step circle */}
                  <div
                    className={`
                      w-10 h-10 rounded-full flex items-center justify-center border-2 transition-all
                      ${isCompleted 
                        ? 'bg-primary border-primary' 
                        : isCurrent 
                        ? 'bg-white border-primary' 
                        : 'bg-white border-muted-foreground/30'
                      }
                    `}
                  >
                    {isCompleted ? (
                      <Check className="w-5 h-5 text-primary-foreground" />
                    ) : (
                      <span className={`text-sm font-medium ${isCurrent ? 'text-primary' : 'text-muted-foreground'}`}>
                        {index + 1}
                      </span>
                    )}
                  </div>
                  
                  {/* Step title */}
                  <div className="mt-2 text-center">
                    <p className={`text-sm font-medium ${isCurrent ? 'text-primary' : isCompleted ? 'text-foreground' : 'text-muted-foreground'}`}>
                      {step.title}
                    </p>
                    {step.description && (
                      <p className="text-xs text-muted-foreground mt-1">
                        {step.description}
                      </p>
                    )}
                  </div>
                </div>

                {/* Connecting line */}
                {!isLast && (
                  <div 
                    className={`
                      flex-1 h-px mx-4 transition-all
                      ${index < currentIndex ? 'bg-primary' : 'bg-muted-foreground/30'}
                    `}
                  />
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}