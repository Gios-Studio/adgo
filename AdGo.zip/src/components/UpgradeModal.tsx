import { useState } from 'react';
import { Crown, Check, X, Star, Zap, Shield, Users } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from './ui/dialog';
import { RadioGroup, RadioGroupItem } from './ui/radio-group';
import { Label } from './ui/label';
import { useSubscription } from '../contexts/SubscriptionContext';

interface UpgradeModalProps {
  isOpen: boolean;
  onClose: () => void;
  feature?: string;
}

const PREMIUM_FEATURES = [
  {
    icon: Users,
    title: 'Advanced Targeting',
    description: 'Municipality-level targeting and radius targeting around specific locations'
  },
  {
    icon: Crown,
    title: 'Premium Cities',
    description: 'Target up to 5 cities per campaign instead of just 1'
  },
  {
    icon: Zap,
    title: 'Multi-Language Support',
    description: 'Reach audiences in their native language with Swahili, French, Arabic, and more'
  },
  {
    icon: Star,
    title: 'Advanced Analytics',
    description: 'Detailed demographic insights, attribution analysis, and optimization recommendations'
  },
  {
    icon: Shield,
    title: 'Priority Support',
    description: 'Get priority customer support and dedicated account management'
  }
];

const PRICING_TIERS = [
  {
    id: 'premium',
    name: 'Premium',
    description: 'Perfect for growing businesses',
    monthlyPrice: 49,
    yearlyPrice: 490,
    features: [
      'Up to 25 campaigns',
      'Target 5 cities per campaign',
      'Advanced targeting options',
      'Multi-language support',
      'Advanced analytics',
      'Priority support',
      'Multiple report recipients'
    ],
    popular: true
  },
  {
    id: 'enterprise',
    name: 'Enterprise',
    description: 'For large-scale operations',
    monthlyPrice: 199,
    yearlyPrice: 1990,
    features: [
      'Unlimited campaigns',
      'Unlimited cities per campaign',
      'All Premium features',
      'Advanced integrations',
      'Dedicated account manager',
      'Custom contracts',
      'White-label options'
    ],
    popular: false
  }
];

export function UpgradeModal({ isOpen, onClose, feature }: UpgradeModalProps) {
  const [selectedPlan, setSelectedPlan] = useState<'premium' | 'enterprise'>('premium');
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'yearly'>('monthly');
  const [isUpgrading, setIsUpgrading] = useState(false);
  const { upgradeToPremium, upgradeToEnterprise, changeBillingCycle } = useSubscription();

  const handleUpgrade = async () => {
    setIsUpgrading(true);
    
    // Simulate upgrade process
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    if (selectedPlan === 'premium') {
      upgradeToPremium();
    } else {
      upgradeToEnterprise();
    }
    
    changeBillingCycle(billingCycle);
    setIsUpgrading(false);
    onClose();
  };

  const selectedTier = PRICING_TIERS.find(tier => tier.id === selectedPlan);
  const price = selectedTier ? (billingCycle === 'yearly' ? selectedTier.yearlyPrice : selectedTier.monthlyPrice) : 0;
  const savings = selectedTier && billingCycle === 'yearly' ? 
    Math.round(((selectedTier.monthlyPrice * 12) - selectedTier.yearlyPrice) / (selectedTier.monthlyPrice * 12) * 100) : 0;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center gap-2">
            <Crown className="w-6 h-6 text-primary" />
            <DialogTitle className="text-2xl">Upgrade to Premium</DialogTitle>
          </div>
          <DialogDescription>
            {feature ? `Unlock ${feature} and all premium features` : 'Unlock advanced targeting, analytics, and more'}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-8">
          {/* Feature Highlights */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {PREMIUM_FEATURES.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <Card key={index} className="p-4 rounded-xl">
                  <div className="space-y-3">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                        <Icon className="w-5 h-5 text-primary" />
                      </div>
                      <h3 className="font-semibold">{feature.title}</h3>
                    </div>
                    <p className="text-sm text-muted-foreground">{feature.description}</p>
                  </div>
                </Card>
              );
            })}
          </div>

          {/* Billing Cycle Toggle */}
          <div className="flex justify-center">
            <div className="bg-secondary/50 p-1 rounded-xl">
              <RadioGroup
                value={billingCycle}
                onValueChange={(value: 'monthly' | 'yearly') => setBillingCycle(value)}
                className="flex"
              >
                <div className="flex items-center space-x-2 px-4 py-2 rounded-lg">
                  <RadioGroupItem value="monthly" id="monthly" />
                  <Label htmlFor="monthly">Monthly</Label>
                </div>
                <div className="flex items-center space-x-2 px-4 py-2 rounded-lg">
                  <RadioGroupItem value="yearly" id="yearly" />
                  <Label htmlFor="yearly" className="flex items-center gap-2">
                    Yearly
                    <Badge variant="secondary" className="text-xs">Save {savings}%</Badge>
                  </Label>
                </div>
              </RadioGroup>
            </div>
          </div>

          {/* Pricing Tiers */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {PRICING_TIERS.map((tier) => (
              <Card
                key={tier.id}
                className={`
                  p-6 rounded-2xl cursor-pointer transition-all relative
                  ${selectedPlan === tier.id 
                    ? 'border-primary bg-primary/5 shadow-lg' 
                    : 'border-border hover:border-primary/50'
                  }
                `}
                onClick={() => setSelectedPlan(tier.id as 'premium' | 'enterprise')}
              >
                {tier.popular && (
                  <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                    <Badge className="bg-primary">Most Popular</Badge>
                  </div>
                )}

                <div className="space-y-4">
                  <div>
                    <h3 className="text-xl font-bold">{tier.name}</h3>
                    <p className="text-sm text-muted-foreground">{tier.description}</p>
                  </div>

                  <div className="space-y-1">
                    <div className="flex items-baseline gap-2">
                      <span className="text-3xl font-bold">
                        ${billingCycle === 'yearly' ? tier.yearlyPrice : tier.monthlyPrice}
                      </span>
                      <span className="text-muted-foreground">
                        /{billingCycle === 'yearly' ? 'year' : 'month'}
                      </span>
                    </div>
                    {billingCycle === 'yearly' && (
                      <p className="text-sm text-green-600">
                        Save ${(tier.monthlyPrice * 12) - tier.yearlyPrice} per year
                      </p>
                    )}
                  </div>

                  <div className="space-y-2">
                    {tier.features.map((feature, index) => (
                      <div key={index} className="flex items-center gap-2">
                        <Check className="w-4 h-4 text-green-600" />
                        <span className="text-sm">{feature}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </Card>
            ))}
          </div>

          {/* Action Buttons */}
          <div className="flex justify-between items-center pt-6 border-t">
            <div className="text-sm text-muted-foreground">
              Cancel anytime • 30-day money back guarantee
            </div>
            
            <div className="flex gap-3">
              <Button variant="outline" onClick={onClose} disabled={isUpgrading}>
                Maybe Later
              </Button>
              <Button
                onClick={handleUpgrade}
                disabled={isUpgrading}
                className="min-w-32"
              >
                {isUpgrading ? (
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
                    Upgrading...
                  </div>
                ) : (
                  <>
                    <Crown className="w-4 h-4 mr-2" />
                    Upgrade to {selectedTier?.name} - ${price}/{billingCycle === 'yearly' ? 'year' : 'month'}
                  </>
                )}
              </Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}