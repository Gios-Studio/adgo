
  # AdGo

  This is a code bundle for AdGo. The original project is available at https://www.figma.com/design/0Iw10awGD3aNRlyzeQdUwE/AdGo.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  